/// Late-payment penalty (جریمه دیرکرد) for an overdue amount.
///
/// `overdueAmount * (penaltyRateBp / 10000) * (daysOverdue / 365)`, rounded.
/// Returns 0 when any input is not positive.
int calculateLatePenalty({
  required int overdueAmount,
  required int penaltyRateBp,
  required int daysOverdue,
}) {
  if (overdueAmount <= 0 || penaltyRateBp <= 0 || daysOverdue <= 0) return 0;
  return (overdueAmount * (penaltyRateBp / 10000.0) * (daysOverdue / 365.0)).round();
}

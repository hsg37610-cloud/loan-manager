﻿import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  /// Closes the drawer and opens [path] ON TOP of the dashboard, so the phone's system back
  /// button returns to the dashboard instead of leaving the app (go() would replace the stack).
  void _open(BuildContext context, String path) {
    final router = GoRouter.of(context);
    final current = router.routeInformationProvider.value.uri.path;
    Navigator.pop(context);
    if (current == path) return;
    router.go('/');
    if (path != '/') router.push(path);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: theme.colorScheme.primaryContainer),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.account_balance_wallet_rounded, size: 48, color: theme.colorScheme.onPrimaryContainer),
                const SizedBox(height: 8),
                Text('مدیریت وام من', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimaryContainer)),
              ]),
            ),
            ListTile(leading: const Icon(Icons.home_rounded), title: const Text('خانه'), onTap: () => _open(context, '/')),
            ListTile(leading: const Icon(Icons.calculate_rounded), title: const Text('محاسبه‌گر وام'), onTap: () => _open(context, '/calculator')),
            ListTile(leading: const Icon(Icons.calendar_month_rounded), title: const Text('اقساط'), onTap: () => _open(context, '/installments')),
            ListTile(leading: const Icon(Icons.list_alt_rounded), title: const Text('وام‌های من'), onTap: () => _open(context, '/loans')),
            const Divider(),
            ListTile(leading: const Icon(Icons.settings_rounded), title: const Text('تنظیمات'), onTap: () => _open(context, '/settings')),
            ListTile(leading: const Icon(Icons.info_outline_rounded), title: const Text('درباره برنامه'), onTap: () => _open(context, '/about')),
          ],
        ),
      ),
    );
  }
}

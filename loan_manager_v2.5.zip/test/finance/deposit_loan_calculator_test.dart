import 'package:flutter_test/flutter_test.dart';
import 'package:loan_manager/core/finance/deposit_interest_calculator.dart';
import 'package:loan_manager/core/finance/deposit_loan_calculator.dart';

void main() {
  test('amortized installment', () {
    expect(DepositLoanCalculator.amortizedInstallment(loanAmount: 100000000, termMonths: 12, nominalRateBp: 1800), 9167999);
    expect(DepositLoanCalculator.amortizedInstallment(loanAmount: 100000000, termMonths: 24, nominalRateBp: 0), 4166667);
  });

  test('IRR: deposit returned at month 12', () {
    final r = DepositLoanCalculator.calculate(loanAmount: 100000000, depositAmount: 50000000, termMonths: 12, nominalRateBp: 1800, depositMonths: 12);
    expect(r.monthlyRate, closeTo(0.07445301, 1e-7));
    expect(r.effectiveAnnualRate, closeTo(1.36727730, 1e-6));
  });

  test('blocked part released with the deposit gives the same rate', () {
    final a = DepositLoanCalculator.calculate(loanAmount: 100000000, depositAmount: 50000000, termMonths: 12, nominalRateBp: 1800, depositMonths: 12);
    final b = DepositLoanCalculator.calculate(loanAmount: 100000000, depositAmount: 50000000, termMonths: 12, nominalRateBp: 1800, depositMonths: 12, blockedAmount: 20000000, blockedMonths: 12);
    expect(b.monthlyRate, closeTo(a.monthlyRate!, 1e-9));
  });

  test('blocked months default to the installment count', () {
    final r = DepositLoanCalculator.calculate(loanAmount: 500000000, depositAmount: 200000000, termMonths: 36, nominalRateBp: 2300, depositMonths: 36, blockedAmount: 100000000);
    expect(r.blockedMonths, 36);
    expect(r.monthlyRate, closeTo(0.04529229, 1e-7));
    expect(r.effectiveAnnualRate, closeTo(0.70158229, 1e-6));
  });

  test('no deposit = ordinary loan rate (1.5% monthly)', () {
    final r = DepositLoanCalculator.calculate(loanAmount: 100000000, depositAmount: 0, termMonths: 12, nominalRateBp: 1800, depositMonths: 1);
    expect(r.monthlyRate, closeTo(0.015, 1e-6));
  });

  test('deposit interest', () {
    expect(DepositInterestCalculator.interest(amount: 100000000, annualRateBp: 2300, days: 365), 23000000);
    expect(DepositInterestCalculator.interest(amount: 10000000, annualRateBp: 2350, days: 30), 193151);
  });
}

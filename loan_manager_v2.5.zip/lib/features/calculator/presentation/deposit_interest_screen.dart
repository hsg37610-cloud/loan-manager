import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/finance/deposit_interest_calculator.dart';
import 'package:loan_manager/core/utils/input_utils.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

/// محاسبه سود سپرده: Interest = (Amount × AnnualRate × Days) / 36500.
class DepositInterestScreen extends StatefulWidget {
  const DepositInterestScreen({super.key});
  @override
  State<DepositInterestScreen> createState() => _DepositInterestScreenState();
}

class _DepositInterestScreenState extends State<DepositInterestScreen> {
  final _amount = TextEditingController();
  final _rate = TextEditingController();
  final _days = TextEditingController();

  @override
  void dispose() {
    _amount.dispose();
    _rate.dispose();
    _days.dispose();
    super.dispose();
  }

  int? get _rateBp {
    final cleaned = normalizeDigits(_rate.text).replaceAll('٫', '.').replaceAll(',', '.').trim();
    final p = double.tryParse(cleaned);
    return (p == null || p < 0) ? null : (p * 100).round();
  }

  int? get _interest {
    final a = parseInt(_amount.text);
    final d = parseInt(_days.text);
    final bp = _rateBp;
    if (a == null || a <= 0 || d == null || d <= 0 || bp == null) return null;
    return DepositInterestCalculator.interest(amount: a, annualRateBp: bp, days: d);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final interest = _interest;
    final amount = parseInt(_amount.text);
    // Used inside the main shell (drawer / dashboard); it has no own Scaffold.
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('محاسبه سود سپرده', style: theme.textTheme.titleLarge),
        const SizedBox(height: 4),
        Text('سود = (مبلغ × نرخ سالانه × تعداد روز) ÷ ۳۶۵۰۰', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        const SizedBox(height: 16),
        TextField(
          controller: _amount,
          keyboardType: TextInputType.number,
          inputFormatters: [const NumericInputFormatter(thousands: true)],
          decoration: const InputDecoration(labelText: 'مبلغ سپرده (تومان)', border: OutlineInputBorder()),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _rate,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'نرخ سود سالانه (%)', border: OutlineInputBorder()),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _days,
          keyboardType: TextInputType.number,
          inputFormatters: [const NumericInputFormatter()],
          decoration: const InputDecoration(labelText: 'مدت (روز)', border: OutlineInputBorder()),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 24),
        if (interest != null)
          Card(
            color: theme.colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('سود سپرده', style: theme.textTheme.titleSmall?.copyWith(color: theme.colorScheme.onPrimaryContainer)),
                Text('${_money.format(interest)} تومان', style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimaryContainer)),
                const SizedBox(height: 8),
                Text('مبلغ سپرده + سود: ${_money.format(amount! + interest)} تومان', style: TextStyle(color: theme.colorScheme.onPrimaryContainer)),
              ]),
            ),
          )
        else
          Text('مبلغ، نرخ و تعداد روز را وارد کنید', style: TextStyle(color: theme.colorScheme.outline)),
      ],
    );
  }
}

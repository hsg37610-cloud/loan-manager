/// Values stored in `loans.loan_type`.
abstract final class LoanType {
  static const String normal = 'normal';
  static const String qarz = 'qarz';

  /// وام با سپرده‌گذاری: the borrower must keep a deposit (part of it possibly blocked).
  static const String depositLoan = 'deposit_loan';
}

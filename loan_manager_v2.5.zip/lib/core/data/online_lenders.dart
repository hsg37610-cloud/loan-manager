/// Predefined online lenders (اعتباردهندگان آنلاین) shown in the lender picker.
class OnlineLender {
  const OnlineLender(this.name, this.logoAsset);
  final String name;
  final String logoAsset;
}

abstract final class OnlineLenders {
  static const List<OnlineLender> all = [
    OnlineLender('دیجی‌پی', 'assets/logos/digipay.svg'),
    OnlineLender('داریک', 'assets/logos/daric.svg'),
    OnlineLender('زرین لند', 'assets/logos/zarinland.svg'),
    OnlineLender('بلو بانک', 'assets/logos/blubank.svg'),
    OnlineLender('لندو', 'assets/logos/lendo.svg'),
    OnlineLender('قسطا', 'assets/logos/ghesta.svg'),
    OnlineLender('وامینو', 'assets/logos/vamino.svg'),
    OnlineLender('کیپا', 'assets/logos/kipa.svg'),
    OnlineLender('اسنپ‌پی', 'assets/logos/snapppay.svg'),
    OnlineLender('ازکی‌وام', 'assets/logos/azkivam.svg'),
    OnlineLender('تکنوپی', 'assets/logos/technopay.svg'),
  ];

  /// The last option of the picker: the user types the lender name by hand.
  static const String manualOption = 'سایر موسسات (ورود دستی)';

  static String _norm(String s) =>
      s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('\u200c', '').replaceAll(' ', '').trim();

  static bool isOnlineLender(String name) => all.any((l) => _norm(l.name) == _norm(name));

  static String? logoAssetFor(String name) {
    final needle = _norm(name);
    if (needle.isEmpty) return null;
    for (final l in all) {
      if (_norm(l.name) == needle) return l.logoAsset;
    }
    return null;
  }
}

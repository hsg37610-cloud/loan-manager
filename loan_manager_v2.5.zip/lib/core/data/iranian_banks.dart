import 'package:loan_manager/core/data/online_lenders.dart';

class IranianBanks {
  static const List<String> all = [
    'بانک ملی ایران', 'بانک سپه', 'بانک صنعت و معدن', 'بانک کشاورزی', 'بانک مسکن',
    'بانک توسعه صادرات', 'بانک توسعه تعاون', 'پست بانک ایران', 'بانک اقتصاد نوین',
    'بانک پارسیان', 'بانک پاسارگاد', 'بانک کارآفرین', 'بانک سامان', 'بانک سینا',
    'بانک خاورمیانه', 'بانک شهر', 'بانک دی', 'بانک صادرات ایران', 'بانک تجارت',
    'بانک ملت', 'بانک رفاه کارگران', 'بانک ایران زمین', 'بانک گردشگری',
    'بانک حکمت ایرانیان', 'بانک انصار', 'بانک مهر ایران', 'موسسه اعتباری ملل',
    'موسسه اعتباری کوثر', 'بانک رسالت'
  ];

  static const Map<String, String> _logos = {
    'بانک ملی ایران': 'assets/banks/melli.svg',
    'بانک ملت': 'assets/banks/mellat.svg',
    'بانک صادرات ایران': 'assets/banks/saderat.svg',
    'بانک تجارت': 'assets/banks/tejarat.svg',
    'بانک سپه': 'assets/banks/sepah.svg',
    'بانک مسکن': 'assets/banks/maskan.svg',
    'بانک پاسارگاد': 'assets/banks/pasargad.svg',
    'بانک سامان': 'assets/banks/saman.svg',
    'بانک پارسیان': 'assets/banks/parsian.svg',
    'بانک رسالت': 'assets/banks/resalat.svg',
    'بانک کشاورزی': 'assets/banks/keshavarzi.svg',
    'بانک شهر': 'assets/banks/shahr.svg',
    'بانک دی': 'assets/banks/dey.svg',
    'بانک سینا': 'assets/banks/sina.svg',
    'بانک کارآفرین': 'assets/banks/karafarin.svg',
    'بانک پست بانک ایران': 'assets/banks/post.svg',
    'پست بانک ایران': 'assets/banks/post.svg',
    'بانک صنعت و معدن': 'assets/banks/sanat-madan.svg',
    'بانک اقتصاد نوین': 'assets/banks/eghtesad-novin.svg',
    'بانک رفاه کارگران': 'assets/banks/refah.svg',
    'موسسه اعتباری کوثر': 'assets/banks/kosar.svg',
    'بانک ایران زمین': 'assets/banks/iran-zamin.svg',
    'بانک گردشگری': 'assets/banks/gardeshgari.svg',
    'بانک حکمت ایرانیان': 'assets/banks/bank-hekmat.svg',
    'بانک انصار': 'assets/banks/ansar.svg',
    'بانک مهر ایران': 'assets/banks/mehr-iran.svg',
    'بانک قوامین': 'assets/banks/ghavamin.svg',
    'بانک خاورمیانه': 'assets/banks/khavar-mianeh.svg',
    'بانک توسعه صادرات': 'assets/banks/tosee-saderat.svg',
    'بانک توسعه تعاون': 'assets/banks/tosee-taavon.svg',
  };

  static String _normalize(String name) {
    var s = name.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('\u200c', ' ');
    for (final word in ['موسسه اعتباری', 'مؤسسه اعتباری', 'بانک']) {
      s = s.replaceAll(word, ' ');
    }
    return s.replaceAll(RegExp(r'\s+'), ' ').trim();
  }

  /// Logo for a bank given its full ("بانک ملی ایران") or short ("ملی") name.
  static String? logoAssetFor(String bankName) {
    final exact = _logos[bankName];
    if (exact != null) return exact;
    final lender = OnlineLenders.logoAssetFor(bankName);
    if (lender != null) return lender;
    final needle = _normalize(bankName);
    if (needle.length < 2) return null;
    String? partial;
    for (final entry in _logos.entries) {
      final key = _normalize(entry.key);
      if (key == needle) return entry.value;
      if (partial == null && (key.contains(needle) || needle.contains(key))) partial = entry.value;
    }
    return partial;
  }
}

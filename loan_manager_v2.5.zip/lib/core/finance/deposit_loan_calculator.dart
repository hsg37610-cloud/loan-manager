import 'dart:math' as math;

/// Result of [DepositLoanCalculator.calculate].
class DepositLoanResult {
  const DepositLoanResult({
    required this.installment,
    required this.totalReturn,
    required this.monthlyRate,
    required this.effectiveAnnualRate,
    required this.blockedMonths,
  });

  /// Standard amortized monthly installment (integer Toman).
  final int installment;

  /// installment × term.
  final int totalReturn;

  /// Real monthly rate `i` found by the cash-flow / NPV bisection, or null when no root exists.
  final double? monthlyRate;

  /// `(1 + i)^12 - 1` (a fraction, 0.35 = 35%), or null when [monthlyRate] is null.
  final double? effectiveAnnualRate;

  /// Blocked months actually used (null when nothing is blocked).
  final int? blockedMonths;

  /// Effective annual rate in basis points (rounded), or null.
  int? get effectiveAnnualRateBp => effectiveAnnualRate == null ? null : (effectiveAnnualRate! * 10000).round();
}

/// «وام با سپرده‌گذاری»: finds the REAL rate of a loan that requires a deposit, using the cash flows
///
///   CF[0]            = loan − deposit
///   CF[1..N]         = −installment
///   CF[blockedMonths] += blocked                (only if blocked > 0)
///   CF[depositMonths] += deposit − blocked
///
/// and solving  Σ CF[t] / (1+i)^t = 0  by bisection on [-0.99, 5.00].
/// Money stays integer Toman; only the rate itself is a double.
abstract final class DepositLoanCalculator {
  static const double lowerBound = -0.99;
  static const double upperBound = 5.00;
  static const int _maxIterations = 200;
  static const double _tolerance = 1e-13;

  /// Standard (French) amortized installment, rounded to the nearest Toman and never so low
  /// that installment × term < loan.
  static int amortizedInstallment({required int loanAmount, required int termMonths, required int nominalRateBp}) {
    if (loanAmount <= 0) throw ArgumentError('Loan amount must be > 0');
    if (termMonths <= 0) throw ArgumentError('Term must be > 0');
    if (nominalRateBp < 0) throw ArgumentError('Rate must be >= 0');
    int ceilDiv(int a, int b) => (a + b - 1) ~/ b;
    if (nominalRateBp == 0) return ceilDiv(loanAmount, termMonths);
    final r = nominalRateBp / 10000 / 12;
    final exact = loanAmount * r / (1 - math.pow(1 + r, -termMonths));
    final rounded = exact.round();
    return rounded * termMonths < loanAmount ? ceilDiv(loanAmount, termMonths) : rounded;
  }

  /// Blocked months to use: null when nothing is blocked, otherwise the entered value, defaulting to [termMonths].
  static int? resolveBlockedMonths({required int blockedAmount, required int? blockedMonths, required int termMonths}) {
    if (blockedAmount <= 0) return null;
    return (blockedMonths == null || blockedMonths <= 0) ? termMonths : blockedMonths;
  }

  static List<double> cashFlows({
    required int loanAmount,
    required int depositAmount,
    required int termMonths,
    required int installment,
    required int depositMonths,
    int blockedAmount = 0,
    int? blockedMonths,
  }) {
    final bm = resolveBlockedMonths(blockedAmount: blockedAmount, blockedMonths: blockedMonths, termMonths: termMonths);
    final length = math.max(termMonths, math.max(depositMonths, bm ?? 0)) + 1;
    final cf = List<double>.filled(length, 0.0);
    cf[0] = (loanAmount - depositAmount).toDouble();
    for (var t = 1; t <= termMonths; t++) {
      cf[t] -= installment;
    }
    if (blockedAmount > 0) cf[bm!] += blockedAmount;
    cf[depositMonths] += depositAmount - blockedAmount;
    return cf;
  }

  static double npv(List<double> cf, double i) {
    final base = 1 + i;
    var sum = 0.0;
    for (var t = 0; t < cf.length; t++) {
      sum += cf[t] / math.pow(base, t);
    }
    return sum;
  }

  /// Bisection inside [lowerBound, upperBound]. When the two ends have the same sign (normal when the
  /// last cash flow is positive, because NPV(-0.99) is dominated by it) the range is first scanned outward
  /// from 0 to find the sign change closest to 0, and bisection runs on that bracket. Null if there is none.
  static double? solveMonthlyRate(List<double> cf) {
    double f(double i) => npv(cf, i);
    if (f(0) == 0) return 0;

    (double, double)? bracket(int direction) {
      const step = 0.001;
      var a = 0.0;
      var fa = f(a);
      while (true) {
        final b = a + direction * step;
        if (b > upperBound || b < lowerBound) return null;
        final fb = f(b);
        if (fb == 0) return (b, b);
        if ((fa < 0) != (fb < 0)) return b > a ? (a, b) : (b, a);
        a = b;
        fa = fb;
      }
    }

    final candidates = [bracket(1), bracket(-1)].whereType<(double, double)>().toList();
    if (candidates.isEmpty) return null;
    candidates.sort((x, y) => math.min(x.$1.abs(), x.$2.abs()).compareTo(math.min(y.$1.abs(), y.$2.abs())));
    var (lo, hi) = candidates.first;
    if (lo == hi) return lo;
    var fLo = f(lo);
    for (var k = 0; k < _maxIterations; k++) {
      final mid = (lo + hi) / 2;
      final fMid = f(mid);
      if (fMid == 0 || hi - lo < _tolerance) return mid;
      if ((fLo < 0) == (fMid < 0)) {
        lo = mid;
        fLo = fMid;
      } else {
        hi = mid;
      }
    }
    return (lo + hi) / 2;
  }

  static DepositLoanResult calculate({
    required int loanAmount,
    required int depositAmount,
    required int termMonths,
    required int nominalRateBp,
    required int depositMonths,
    int blockedAmount = 0,
    int? blockedMonths,
  }) {
    if (depositAmount < 0) throw ArgumentError('Deposit must be >= 0');
    if (depositMonths < 1) throw ArgumentError('Deposit months must be >= 1');
    if (blockedAmount < 0 || blockedAmount > depositAmount) throw ArgumentError('Blocked amount must be within 0..deposit');
    final installment = amortizedInstallment(loanAmount: loanAmount, termMonths: termMonths, nominalRateBp: nominalRateBp);
    final bm = resolveBlockedMonths(blockedAmount: blockedAmount, blockedMonths: blockedMonths, termMonths: termMonths);
    final cf = cashFlows(
      loanAmount: loanAmount,
      depositAmount: depositAmount,
      termMonths: termMonths,
      installment: installment,
      depositMonths: depositMonths,
      blockedAmount: blockedAmount,
      blockedMonths: bm,
    );
    final i = solveMonthlyRate(cf);
    return DepositLoanResult(
      installment: installment,
      totalReturn: installment * termMonths,
      monthlyRate: i,
      effectiveAnnualRate: i == null ? null : (math.pow(1 + i, 12) - 1).toDouble(),
      blockedMonths: bm,
    );
  }
}

import 'package:flutter/material.dart';
import 'package:loan_manager/shared/widgets/app_back_button.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});
  static const String appName = 'مدیریت وام من';
  static const String version = '2.1';
  static const String developer = 'hossein.seifollahzade';

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(leading: const AppBackButton(), title: const Text('درباره برنامه')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 24),
          Center(child: Container(width: 112, height: 112, decoration: BoxDecoration(color: theme.colorScheme.primaryContainer, borderRadius: BorderRadius.circular(28)), child: Icon(Icons.account_balance_wallet_rounded, size: 64, color: theme.colorScheme.onPrimaryContainer))),
          const SizedBox(height: 16),
          Text(appName, textAlign: TextAlign.center, style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('نسخه $version', textAlign: TextAlign.center, style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.outline)),
          const SizedBox(height: 32),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            _row(context, Icons.person_outline, 'توسعه‌دهنده', developer),
            const Divider(),
            _row(context, Icons.copyright_rounded, 'کپی‌رایت', '© 1405'),
            const Divider(),
            _row(context, Icons.code_rounded, 'ساخته شده با', 'Flutter + Drift + Riverpod'),
            const Divider(),
            _row(context, Icons.calendar_month_outlined, 'تقویم', 'جلالی (شمسی)'),
          ]))),
          const SizedBox(height: 32),
          Text('All Rights Reserved © 1405', textAlign: TextAlign.center, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline)),
        ],
      ),
    );
  }
  Widget _row(BuildContext context, IconData icon, String label, String value) {
    final theme = Theme.of(context);
    return Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [
      Icon(icon, size: 20, color: theme.colorScheme.primary), const SizedBox(width: 12),
      Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w500))),
      Text(value, style: TextStyle(color: theme.colorScheme.onSurfaceVariant), textDirection: TextDirection.ltr),
    ]));
  }
}

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:drift/drift.dart';
import 'package:excel/excel.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:loan_manager/core/database/app_database.dart';
import 'package:loan_manager/core/database/app_database_provider.dart';
import 'package:loan_manager/core/utils/jalali_utils.dart';
import 'package:shamsi_date/shamsi_date.dart';

import '../../export/data/export_data.dart';

final excelImportServiceProvider = Provider<ExcelImportService>(
  (ref) => ExcelImportService(ref.read(appDatabaseProvider)),
);

class ImportException implements Exception {
  const ImportException(this.message);

  final String message;

  @override
  String toString() => message;
}

class ImportSummary {
  const ImportSummary({
    required this.loans,
    required this.installments,
    required this.payments,
    required this.skipped,
  });

  final int loans;
  final int installments;
  final int payments;
  final int skipped;

  String get report {
    final text = '$loans وام ($installments قسط و $payments پرداخت) وارد شد';
    if (skipped > 0) return '$text؛ $skipped وام به دلیل تکرار شناسه نادیده گرفته شد';
    return text;
  }
}

// ---- background parsing ------------------------------------------------------
//
// Excel.decodeBytes() is synchronous and CPU-heavy: on the main isolate it blocks the UI thread
// (ANR / black screen on Android 13+). Everything that touches the `excel` package therefore runs
// in parseExcelInBackground(), executed through compute(). Only plain Maps/Lists/Strings travel
// back to the main isolate.

const int _maxImportRows = 5000; // hard cap per sheet
const int _maxEmptyRowsInARow = 20;
const int _maxImportColumns = 64;
const int _maxXlsxBytes = 20 * 1024 * 1024;
const int _maxUncompressedXlsxBytes = 32 * 1024 * 1024;
const int _maxWorksheetXmlBytes = 8 * 1024 * 1024;

class _SheetData {
  const _SheetData(this.headers, this.rows);
  final List<String> headers;
  final List<Map<String, dynamic>> rows;
}

/// Top-level (required by compute). Returns a map with the keys
/// `loans`, `installments`, `payments` (lists of `{header: text}` maps, each row also carries
/// `__row`, its 0-based sheet row index), `loansHeaders` / `installmentsHeaders` /
/// `paymentsHeaders`, or just `error` (a user-facing message) when the file is unusable.
Map<String, dynamic> parseExcelInBackground(Uint8List bytes) {
  const invalid = 'فایل یک اکسل معتبر نیست';
  // An .xlsx file is a ZIP archive: it must start with "PK" (0x50 0x4B).
  if (bytes.length < 4 || bytes[0] != 0x50 || bytes[1] != 0x4B) {
    return {'error': invalid};
  }

  // Inspect ZIP metadata before invoking the workbook decoder. XLSX is a ZIP
  // container; a tiny file can declare enormous worksheet dimensions (or contain
  // highly-compressed XML). The excel package expands workbook structures while
  // decoding, so an isolate alone cannot protect the Android process from OOM.
  try {
    final archive = ZipDecoder().decodeBytes(bytes);
    var uncompressedBytes = 0;
    var worksheetCount = 0;
    for (final entry in archive.files) {
      if (!entry.isFile) continue;
      uncompressedBytes += entry.size;
      if (uncompressedBytes > _maxUncompressedXlsxBytes) {
        return {'error': 'حجم بازشده فایل اکسل بیش از حد مجاز است؛ فایل را دوباره ذخیره و امتحان کنید'};
      }
      if (entry.name.startsWith('xl/worksheets/') && entry.name.endsWith('.xml')) {
        worksheetCount++;
        if (entry.size > _maxWorksheetXmlBytes) {
          return {'error': 'یکی از برگه‌های اکسل غیرعادی بزرگ است'};
        }
        final xml = utf8.decode(entry.content as List<int>, allowMalformed: true);
        final dimension = RegExp(r'<dimension\b[^>]*\bref=["\']([^"\']+)["\']').firstMatch(xml);
        final ref = dimension?.group(1);
        if (ref != null) {
          final end = ref.split(':').last.replaceAll(r'$', '');
          final match = RegExp(r'^([A-Z]+)([0-9]+)$', caseSensitive: false).firstMatch(end);
          if (match != null) {
            final col = _xlsxColumnNumber(match.group(1)!);
            final row = int.tryParse(match.group(2)!) ?? 0;
            if (row > _maxImportRows + 1 || col > _maxImportColumns) {
              return {'error': 'ابعاد اعلام‌شده یکی از برگه‌های اکسل غیرعادی است (احتمال وجود محدوده خالی یا خراب). فایل را در Excel باز و با Save As ذخیره کنید'};
            }
          }
        }
      }
    }
    if (worksheetCount == 0) return {'error': invalid};
  } catch (_) {
    return {'error': invalid};
  }

  final Excel excel;
  try {
    excel = Excel.decodeBytes(bytes);
  } catch (_) {
    return {'error': invalid};
  }

  try {
    final loansSheet = excel.tables[ExportContract.loansSheet];
    if (loansSheet == null) {
      return {'error': 'برگه «Loans» با ردیف داده در فایل یافت نشد'};
    }
    final loans = _extractSheet(loansSheet);
    if (loans.rows.isEmpty) {
      return {'error': 'برگه «Loans» با ردیف داده در فایل یافت نشد'};
    }

    final installmentsSheet = excel.tables[ExportContract.installmentsSheet];
    final installments = installmentsSheet == null ? const _SheetData([], []) : _extractSheet(installmentsSheet);

    final paymentsSheet = excel.tables[ExportContract.paymentsSheet];
    final payments = paymentsSheet == null ? const _SheetData([], []) : _extractSheet(paymentsSheet);

    return {
      'loans': loans.rows,
      'installments': installments.rows,
      'payments': payments.rows,
      'loansHeaders': loans.headers,
      'installmentsHeaders': installments.headers,
      'paymentsHeaders': payments.headers,
    };
  } catch (_) {
    return {'error': invalid};
  }
}

int _xlsxColumnNumber(String letters) {
  var value = 0;
  for (final code in letters.toUpperCase().codeUnits) {
    if (code < 65 || code > 90) return 0;
    value = value * 26 + code - 64;
  }
  return value;
}

/// Reads one sheet row by row (never `sheet.rows`, which materialises the whole - possibly
/// phantom - dimension of the sheet): at most [_maxImportRows] rows, and it stops after
/// [_maxEmptyRowsInARow] consecutive empty rows.
_SheetData _extractSheet(Sheet sheet) {
  final rowLimit = sheet.maxRows < _maxImportRows ? sheet.maxRows : _maxImportRows;
  if (rowLimit <= 0) return const _SheetData([], []);
  final colLimit = sheet.maxColumns < _maxImportColumns ? sheet.maxColumns : _maxImportColumns;

  final headerByColumn = <int, String>{};
  final headerCells = sheet.row(0);
  for (var c = 0; c < colLimit && c < headerCells.length; c++) {
    final text = _cellText(headerCells[c]);
    if (text != null) headerByColumn[c] = text;
  }

  final rows = <Map<String, dynamic>>[];
  var emptyInARow = 0;
  for (var r = 1; r < rowLimit; r++) {
    final cells = sheet.row(r);
    final row = <String, dynamic>{};
    for (final entry in headerByColumn.entries) {
      if (entry.key >= cells.length) continue;
      final text = _cellText(cells[entry.key]);
      if (text != null) row[entry.value] = text;
    }
    if (row.isEmpty) {
      emptyInARow++;
      if (emptyInARow >= _maxEmptyRowsInARow) break;
      continue;
    }
    emptyInARow = 0;
    row['__row'] = r;
    rows.add(row);
  }
  return _SheetData(headerByColumn.values.toList(), rows);
}

/// `cell.value.toString()`, trimmed; null for empty cells. Whole doubles lose their ".0".
String? _cellText(Data? cell) {
  final v = cell?.value;
  if (v == null) return null;
  final String text;
  if (v is TextCellValue) {
    text = v.value.toString();
  } else if (v is DoubleCellValue) {
    final d = v.value;
    text = d == d.roundToDouble() ? d.toInt().toString() : d.toString();
  } else {
    text = v.toString();
  }
  final trimmed = text.trim();
  return trimmed.isEmpty ? null : trimmed;
}

/// Reads a 3-sheet xlsx file produced by [ExcelExportService] and inserts it
/// into the database. A loan whose `id` already exists is skipped together
/// with its installments/payments, so re-importing a file is safe.
class ExcelImportService {
  ExcelImportService(this._db);

  final AppDatabase _db;

  /// Legacy path-based entry point; prefer [importBytes] (Android 13+ restricts raw file paths).
  Future<ImportSummary> importFile(String path) async {
    final Uint8List bytes;
    try {
      bytes = File(path).readAsBytesSync();
    } catch (_) {
      throw const ImportException('خواندن فایل ممکن نبود');
    }
    return importBytes(bytes);
  }

  /// Imports an xlsx file whose content is already in memory.
  Future<ImportSummary> importBytes(Uint8List bytes) async {
    if (bytes.isEmpty) throw const ImportException('فایل خالی است');
    if (bytes.lengthInBytes > _maxXlsxBytes) {
      throw const ImportException('حجم فایل بیش از ۲۰ مگابایت است');
    }
    // Heavy decoding runs in a background isolate. ZIP preflight inside the
    // worker rejects oversized/phantom worksheet dimensions before Excel.decodeBytes.
    final Map<String, dynamic> parsed;
    try {
      parsed = await compute(parseExcelInBackground, bytes);
    } catch (_) {
      throw const ImportException('فایل یک اکسل معتبر نیست');
    }
    final error = parsed['error'];
    if (error is String) throw ImportException(error);

    final loans = _readLoans(_rowsOf(parsed['loans']), _headersOf(parsed['loansHeaders']));
    final installments = _readInstallments(_rowsOf(parsed['installments']), _headersOf(parsed['installmentsHeaders']));
    final payments = _readPayments(_rowsOf(parsed['payments']), _headersOf(parsed['paymentsHeaders']));

    // The export writes the loan NAME in the «وام» column of the Installments and
    // Payments sheets (not the id), so resolve each reference: id first, then a
    // name that is unique among the loans of the file.
    final fileLoanIds = {for (final l in loans) l.id};
    final idByName = <String, String?>{};
    for (final l in loans) {
      idByName[l.name] = idByName.containsKey(l.name) ? null : l.id;
    }
    String resolveLoanRef(String ref) => fileLoanIds.contains(ref) ? ref : (idByName[ref] ?? ref);
    for (final i in installments) {
      i.loanId = resolveLoanRef(i.loanId);
    }
    for (final p in payments) {
      p.loanId = resolveLoanRef(p.loanId);
    }

    // Every installment/payment must reference a loan that is in the file
    // or already exists in the database.
    final referenced = {
      for (final l in loans) l.id,
      for (final i in installments) i.loanId,
      for (final p in payments) p.loanId,
    };
    final existing = await (_db.select(_db.loans)..where((t) => t.id.isIn(referenced))).get();
    final knownLoanIds = {
      for (final l in loans) l.id,
      for (final r in existing) r.id,
    };
    for (final i in installments) {
      if (!knownLoanIds.contains(i.loanId)) {
        throw ImportException('قسط شماره ${i.sequenceNumber} متعلق به وام ناشناخته‌ای است');
      }
    }
    for (final p in payments) {
      if (!knownLoanIds.contains(p.loanId)) {
        throw ImportException('پرداختی برای وام ناشناخته‌ای یافت شد');
      }
    }

    final now = DateTime.now().toUtc().toIso8601String();
    var importedLoans = 0;
    var skipped = 0;
    var importedInstallments = 0;
    var importedPayments = 0;

    // Read existing IDs once. The old implementation issued one SELECT per loan
    // and one INSERT per child row; large workbooks created thousands of SQLite
    // round-trips inside a single transaction.
    final incomingIds = loans.map((l) => l.id).toSet();
    final existingRows = incomingIds.isEmpty
        ? <LoanRow>[]
        : await (_db.select(_db.loans)..where((t) => t.id.isIn(incomingIds))).get();
    final existingIds = {for (final row in existingRows) row.id};
    skipped = existingIds.length;
    final newLoans = loans.where((l) => !existingIds.contains(l.id)).toList();
    final newLoanIds = {for (final l in newLoans) l.id};

    final loanRows = <LoansCompanion>[];
    for (final l in newLoans) {
      loanRows.add(LoansCompanion.insert(
        id: l.id,
        name: l.name,
        bankName: Value(l.bankName),
        cardBin: Value(l.cardBin),
        principal: l.principal,
        annualRateBp: Value(l.annualRateBp),
        termMonths: l.termMonths,
        firstDueDate: l.firstDueDate,
        dueDay: l.dueDay,
        installmentAmount: l.installmentAmount,
        totalInterest: l.totalInterest,
        totalReturn: l.totalReturn,
        effectiveRateBp: l.effectiveRateBp,
        calculationMethod: l.calculationMethod,
        calculationVersion: Value(l.calculationVersion ?? 1),
        currency: Value(l.currency ?? 'IRT'),
        status: Value(l.status ?? 'active'),
        settledDate: Value(l.settledDate),
        note: Value(l.note),
        facilityNumber: Value(l.facilityNumber),
        paymentLink: Value(l.paymentLink),
        loanType: Value(l.loanType ?? 'normal'),
        feeAmount: Value(l.feeAmount),
        createdAt: now,
        updatedAt: now,
      ));
    }

    final installmentRows = <InstallmentsCompanion>[];
    for (final i in installments) {
      if (!newLoanIds.contains(i.loanId)) continue;
      installmentRows.add(InstallmentsCompanion.insert(
        id: i.id,
        loanId: i.loanId,
        sequenceNumber: i.sequenceNumber,
        dueDate: i.dueDate,
        jalaliMonth: JalaliUtils.formatJalali(i.dueDate).substring(0, 7).replaceAll('/', '-'),
        amount: i.amount,
        paidAmount: Value(i.paidAmount),
        waivedAmount: Value(i.waivedAmount),
        createdAt: now,
        updatedAt: now,
      ));
    }

    final paymentRows = <PaymentsCompanion>[];
    for (final p in payments) {
      if (!newLoanIds.contains(p.loanId)) continue;
      paymentRows.add(PaymentsCompanion.insert(
        id: p.id,
        loanId: p.loanId,
        paymentDate: p.paymentDate,
        amount: p.amount,
        unallocatedAmount: Value(p.unallocatedAmount),
        referenceNumber: Value(p.referenceNumber),
        note: Value(p.note),
        createdAt: now,
        updatedAt: now,
      ));
    }

    // Bounded batches keep SQL statement size and transient memory predictable.
    // A single transaction preserves all-or-nothing import semantics.
    await _db.transaction(() async {
      await _insertLoanChunks(_db, loanRows);
      await _insertInstallmentChunks(_db, installmentRows);
      await _insertPaymentChunks(_db, paymentRows);
    });
    importedLoans = loanRows.length;
    importedInstallments = installmentRows.length;
    importedPayments = paymentRows.length;

    return ImportSummary(
      loans: importedLoans,
      installments: importedInstallments,
      payments: importedPayments,
      skipped: skipped,
    );
  }

  // ---- parsing (works on the plain maps returned by parseExcelInBackground) -----

  List<Map<String, dynamic>> _rowsOf(Object? raw) =>
      [for (final e in (raw as List? ?? const [])) Map<String, dynamic>.from(e as Map)];

  Set<String> _headersOf(Object? raw) => {for (final e in (raw as List? ?? const [])) e.toString()};

  List<_ParsedLoan> _readLoans(List<Map<String, dynamic>> rows, Set<String> h) {
    for (final required in ['شناسه', 'نام وام', 'مبلغ کل', 'تعداد قسط', 'تاریخ اولین قسط', 'روز سررسید',
      'مبلغ هر قسط', 'سود کل', 'مبلغ بازپرداخت', 'نرخ مؤثر (bp)', 'روش محاسبه']) {
      if (!h.contains(required)) {
        throw ImportException('ستون «$required» در برگه Loans یافت نشد');
      }
    }

    final result = <_ParsedLoan>[];
    for (final data in rows) {
      final row = _Row(data);
      final r = row.number;

      final id = row.text('شناسه');
      if (id == null) throw ImportException('ردیف $r در برگه Loans بدون شناسه است');

      final firstDue = _requiredDate(row, 'تاریخ اولین قسط', r, id);
      result.add(_ParsedLoan(
        id: id,
        name: _requiredText(row, 'نام وام', r, id)!,
        bankName: row.text('بانک'),
        cardBin: row.text('کارت بانکی'),
        principal: _requiredInt(row, 'مبلغ کل', r, id)!,
        annualRateBp: row.intAt('نرخ سالانه (bp)'),
        termMonths: _requiredInt(row, 'تعداد قسط', r, id)!,
        firstDueDate: firstDue,
        dueDay: _requiredInt(row, 'روز سررسید', r, id)!,
        installmentAmount: _requiredInt(row, 'مبلغ هر قسط', r, id)!,
        totalInterest: _requiredInt(row, 'سود کل', r, id)!,
        totalReturn: _requiredInt(row, 'مبلغ بازپرداخت', r, id)!,
        effectiveRateBp: _requiredInt(row, 'نرخ مؤثر (bp)', r, id)!,
        calculationMethod: _requiredText(row, 'روش محاسبه', r, id)!,
        calculationVersion: row.intAt('نسخه روش'),
        currency: row.text('ارز'),
        status: row.text('وضعیت'),
        settledDate: _optionalDate(row, 'تاریخ تسویه'),
        note: row.text('یادداشت'),
        facilityNumber: row.text('شماره تسهیلات'),
        paymentLink: row.text('پیوند پرداخت'),
        loanType: row.text('نوع وام'),
        feeAmount: row.intAt('کارمزد'),
      ));
    }
    if (result.isEmpty) {
      throw const ImportException('برگه Loans بدون داده است');
    }
    return result;
  }

  List<_ParsedInstallment> _readInstallments(List<Map<String, dynamic>> rows, Set<String> h) {
    if (rows.isEmpty) return <_ParsedInstallment>[];
    for (final required in ['شناسه', 'وام', 'شماره قسط', 'سررسید', 'مبلغ']) {
      if (!h.contains(required)) {
        throw ImportException('ستون «$required» در برگه Installments یافت نشد');
      }
    }

    final result = <_ParsedInstallment>[];
    for (final data in rows) {
      final row = _Row(data);
      final r = row.number;

      final id = row.text('شناسه');
      if (id == null) throw ImportException('ردیف $r در برگه Installments بدون شناسه است');
      final due = _requiredDate(row, 'سررسید', r, id);

      result.add(_ParsedInstallment(
        id: id,
        loanId: _requiredText(row, 'وام', r, id)!,
        sequenceNumber: _requiredInt(row, 'شماره قسط', r, id)!,
        dueDate: due,
        amount: _requiredInt(row, 'مبلغ', r, id)!,
        paidAmount: row.intAt('پرداخت‌شده') ?? 0,
        waivedAmount: row.intAt('بخشوده‌شده') ?? 0,
      ));
    }
    return result;
  }

  List<_ParsedPayment> _readPayments(List<Map<String, dynamic>> rows, Set<String> h) {
    if (rows.isEmpty) return <_ParsedPayment>[];
    for (final required in ['شناسه', 'وام', 'تاریخ پرداخت', 'مبلغ']) {
      if (!h.contains(required)) {
        throw ImportException('ستون «$required» در برگه Payments یافت نشد');
      }
    }

    final result = <_ParsedPayment>[];
    for (final data in rows) {
      final row = _Row(data);
      final r = row.number;

      final id = row.text('شناسه');
      if (id == null) throw ImportException('ردیف $r در برگه Payments بدون شناسه است');
      final paidAt = _requiredDate(row, 'تاریخ پرداخت', r, id);

      result.add(_ParsedPayment(
        id: id,
        loanId: _requiredText(row, 'وام', r, id)!,
        paymentDate: paidAt,
        amount: _requiredInt(row, 'مبلغ', r, id)!,
        unallocatedAmount: row.intAt('تخصیص‌نیافته') ?? 0,
        referenceNumber: row.text('شماره مرجع'),
        note: row.text('یادداشت'),
      ));
    }
    return result;
  }

  // ---- validation helpers ----------------------------------------------------

  String? _requiredText(_Row row, String header, int rowNo, String id) {
    final v = row.text(header);
    if (v == null) throw ImportException('ستون «$header» در ردیف $rowNo (شناسه $id) خالی است');
    return v;
  }

  int? _requiredInt(_Row row, String header, int rowNo, String id) {
    final v = row.intAt(header);
    if (v == null) throw ImportException('ستون «$header» در ردیف $rowNo (شناسه $id) عدد معتبر نیست');
    return v;
  }

  String _requiredDate(_Row row, String header, int rowNo, String id) {
    final v = row.text(header);
    final iso = v == null ? null : _jalaliToIso(v);
    if (iso == null) throw ImportException('تاریخ «$header» در ردیف $rowNo (شناسه $id) معتبر نیست');
    return iso;
  }

  String? _optionalDate(_Row row, String header) {
    final v = row.text(header);
    return v == null ? null : _jalaliToIso(v);
  }

  /// Accepts Jalali `yyyy/MM/dd` (as written by the export) and returns
  /// Gregorian `yyyy-MM-dd`. Returns null for anything invalid.
  String? _jalaliToIso(String s) {
    final parts = s.trim().replaceAll('/', '-').split('-');
    if (parts.length != 3) return null;
    final y = int.tryParse(parts[0]);
    final m = int.tryParse(parts[1]);
    final d = int.tryParse(parts[2]);
    if (y == null || m == null || d == null) return null;
    try {
      return Jalali(y, m, d).toGregorian().toDateTime().toIso8601String().substring(0, 10);
    } catch (_) {
      return null;
    }
  }
}

Future<void> _insertLoanChunks(AppDatabase db, List<LoansCompanion> rows) async {
  for (var i = 0; i < rows.length; i += 100) {
    final end = i + 100 < rows.length ? i + 100 : rows.length;
    await db.batch((batch) => batch.insertAll(db.loans, rows.sublist(i, end)));
  }
}

Future<void> _insertInstallmentChunks(AppDatabase db, List<InstallmentsCompanion> rows) async {
  for (var i = 0; i < rows.length; i += 100) {
    final end = i + 100 < rows.length ? i + 100 : rows.length;
    await db.batch((batch) => batch.insertAll(db.installments, rows.sublist(i, end)));
  }
}

Future<void> _insertPaymentChunks(AppDatabase db, List<PaymentsCompanion> rows) async {
  for (var i = 0; i < rows.length; i += 100) {
    final end = i + 100 < rows.length ? i + 100 : rows.length;
    await db.batch((batch) => batch.insertAll(db.payments, rows.sublist(i, end)));
  }
}

// ---- parsed row holders ------------------------------------------------------

class _ParsedLoan {
  _ParsedLoan({
    required this.id,
    required this.name,
    required this.principal,
    required this.termMonths,
    required this.firstDueDate,
    required this.dueDay,
    required this.installmentAmount,
    required this.totalInterest,
    required this.totalReturn,
    required this.effectiveRateBp,
    required this.calculationMethod,
    this.bankName,
    this.cardBin,
    this.annualRateBp,
    this.calculationVersion,
    this.currency,
    this.status,
    this.settledDate,
    this.note,
    this.facilityNumber,
    this.paymentLink,
    this.loanType,
    this.feeAmount,
  });

  final String id;
  final String name;
  final String? bankName;
  final String? cardBin;
  final int principal;
  final int? annualRateBp;
  final int termMonths;
  final String firstDueDate;
  final int dueDay;
  final int installmentAmount;
  final int totalInterest;
  final int totalReturn;
  final int effectiveRateBp;
  final String calculationMethod;
  final int? calculationVersion;
  final String? currency;
  final String? status;
  final String? settledDate;
  final String? note;
  final String? facilityNumber;
  final String? paymentLink;
  final String? loanType;
  final int? feeAmount;
}

class _ParsedInstallment {
  _ParsedInstallment({
    required this.id,
    required this.loanId,
    required this.sequenceNumber,
    required this.dueDate,
    required this.amount,
    required this.paidAmount,
    required this.waivedAmount,
  });

  final String id;
  String loanId;
  final int sequenceNumber;
  final String dueDate;
  final int amount;
  final int paidAmount;
  final int waivedAmount;
}

class _ParsedPayment {
  _ParsedPayment({
    required this.id,
    required this.loanId,
    required this.paymentDate,
    required this.amount,
    required this.unallocatedAmount,
    this.referenceNumber,
    this.note,
  });

  final String id;
  String loanId;
  final String paymentDate;
  final int amount;
  final int unallocatedAmount;
  final String? referenceNumber;
  final String? note;
}

/// One parsed sheet row: `{header: text}` plus `__row` (sheet row index, for error messages).
class _Row {
  _Row(this._data);

  final Map<String, dynamic> _data;

  int get number => (_data['__row'] as int?) ?? 0;

  String? text(String header) {
    final v = _data[header];
    if (v == null) return null;
    final s = v.toString().trim();
    return s.isEmpty ? null : s;
  }

  int? intAt(String header) {
    final s = text(header);
    if (s == null) return null;
    final i = int.tryParse(s);
    if (i != null) return i;
    final d = double.tryParse(s);
    return d?.round();
  }
}

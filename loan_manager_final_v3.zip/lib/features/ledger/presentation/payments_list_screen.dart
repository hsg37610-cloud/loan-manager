import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/utils/jalali_utils.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:loan_manager/features/ledger/presentation/ledger_providers.dart';
import 'package:loan_manager/shared/widgets/app_back_button.dart';
import 'package:share_plus/share_plus.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

/// Builds the text report for one or more payments (oldest first).
String buildPaymentsReport(Iterable<Payment> payments) {
  final sorted = payments.toList()..sort((a, b) => a.paymentDate.compareTo(b.paymentDate));
  final total = sorted.fold<int>(0, (sum, p) => sum + p.amount);
  final lines = [for (final p in sorted) '- ${JalaliUtils.formatJalali(p.paymentDate)}: ${_money.format(p.amount)} تومان'];
  return 'گزارش پرداخت‌ها:\n${lines.join('\n')}\nمجموع: ${_money.format(total)} تومان';
}

class PaymentsListScreen extends ConsumerStatefulWidget {
  const PaymentsListScreen({super.key, required this.loanId});
  final String loanId;

  @override
  ConsumerState<PaymentsListScreen> createState() => _PaymentsListScreenState();
}

class _PaymentsListScreenState extends ConsumerState<PaymentsListScreen> {
  final Set<String> _selected = {};

  void _toggle(String id) {
    setState(() {
      if (!_selected.remove(id)) _selected.add(id);
    });
  }

  void _toggleAll(List<Payment> payments) {
    setState(() {
      final allSelected = payments.isNotEmpty && payments.every((p) => _selected.contains(p.id));
      _selected.clear();
      if (!allSelected) _selected.addAll(payments.map((p) => p.id));
    });
  }

  Future<void> _share(Iterable<Payment> payments) async {
    if (payments.isEmpty) return;
    await SharePlus.instance.share(ShareParams(text: buildPaymentsReport(payments)));
  }

  @override
  Widget build(BuildContext context) {
    final paymentsAsync = ref.watch(paymentsForLoanProvider(widget.loanId));
    final payments = paymentsAsync.value ?? const <Payment>[];
    final selectedItems = payments.where((p) => _selected.contains(p.id)).toList();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        title: Text(selectedItems.isEmpty ? 'پرداخت‌ها' : '${selectedItems.length} مورد انتخاب شده'),
        actions: [
          IconButton(
            tooltip: 'انتخاب همه',
            icon: const Icon(Icons.select_all_rounded),
            onPressed: payments.isEmpty ? null : () => _toggleAll(payments),
          ),
          if (selectedItems.isNotEmpty)
            IconButton(
              tooltip: 'اشتراک‌گذاری انتخاب‌شده‌ها',
              icon: const Icon(Icons.share_outlined),
              onPressed: () => _share(selectedItems),
            ),
        ],
      ),
      body: paymentsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, _) => Center(child: Text('خطا در بارگذاری پرداخت‌ها', style: TextStyle(color: theme.colorScheme.error))),
        data: (items) {
          if (items.isEmpty) return const Center(child: Text('هنوز پرداختی ثبت نشده'));
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final payment = items[index];
              return _PaymentTile(
                payment: payment,
                selected: _selected.contains(payment.id),
                onToggle: () => _toggle(payment.id),
                onShare: () => _share([payment]),
              );
            },
          );
        },
      ),
    );
  }
}

class _PaymentTile extends StatelessWidget {
  const _PaymentTile({required this.payment, required this.selected, required this.onToggle, required this.onShare});
  final Payment payment;
  final bool selected;
  final VoidCallback onToggle;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final note = payment.note;
    return Card(
      clipBehavior: Clip.antiAlias,
      color: selected ? theme.colorScheme.primaryContainer.withValues(alpha: 0.3) : null,
      child: InkWell(
        onTap: onToggle,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            children: [
              Checkbox(value: selected, onChanged: (_) => onToggle()),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(JalaliUtils.formatJalali(payment.paymentDate), style: theme.textTheme.titleSmall),
                    if (note != null && note.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(note, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                    ],
                  ],
                ),
              ),
              Text('${_money.format(payment.amount)} تومان', style: theme.textTheme.titleSmall),
              IconButton(tooltip: 'اشتراک‌گذاری', icon: const Icon(Icons.share_outlined, size: 20), onPressed: onShare),
            ],
          ),
        ),
      ),
    );
  }
}

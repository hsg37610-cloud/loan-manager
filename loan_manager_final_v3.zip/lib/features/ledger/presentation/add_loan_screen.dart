import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/finance/interest_calculator.dart';
import 'package:loan_manager/core/router/app_router.dart';
import 'package:loan_manager/core/utils/input_utils.dart';
import 'package:loan_manager/features/ledger/presentation/ledger_providers.dart';
import 'package:loan_manager/shared/widgets/app_back_button.dart';
import 'package:loan_manager/shared/widgets/bank_autocomplete_field.dart';
import 'package:loan_manager/shared/widgets/jalali_date_picker.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

class AddLoanScreen extends ConsumerStatefulWidget {
  final String? loanId;
  const AddLoanScreen({super.key, this.loanId});
  bool get isEditMode => loanId != null;
  @override
  ConsumerState<AddLoanScreen> createState() => _AddLoanScreenState();
}

class _AddLoanScreenState extends ConsumerState<AddLoanScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController(); final _principal = TextEditingController(); final _rate = TextEditingController();
  final _term = TextEditingController(); final _installment = TextEditingController(); final _fee = TextEditingController();
  final _serviceFee = TextEditingController(); final _manualInstallment = TextEditingController();
  final _dueDay = TextEditingController(); final _facility = TextEditingController(); final _paymentLink = TextEditingController();

  String? _selectedBank; String _loanType = 'normal'; bool _reverseCalc = false; DateTime? _firstDueDate;
  bool _isLoading = false; bool _hasPayments = false; bool _loaded = false;

  @override
  void initState() { super.initState(); if (widget.isEditMode) _loadExistingLoan(); }

  Future<void> _loadExistingLoan() async {
    setState(() => _isLoading = true);
    try {
      final repo = ref.read(ledgerRepositoryProvider);
      final loan = await repo.watchLoan(widget.loanId!).first;
      final installments = await repo.watchInstallmentsForLoan(widget.loanId!).first;
      final serviceFee = await repo.getServiceFee(widget.loanId!);
      if (loan != null && mounted) {
        setState(() {
          _name.text = loan.name; _selectedBank = loan.bankName; _principal.text = loan.principal.toString();
          _term.text = loan.termMonths.toString(); _rate.text = ((loan.annualRateBp ?? 0) / 100).toStringAsFixed(2);
          _fee.text = loan.feeAmount?.toString() ?? ''; _serviceFee.text = serviceFee?.toString() ?? '';
          _facility.text = loan.facilityNumber ?? ''; _paymentLink.text = loan.paymentLink ?? ''; _dueDay.text = loan.dueDay.toString();
          _firstDueDate = DateTime.tryParse(loan.firstDueDate); _loanType = loan.loanType;
          _hasPayments = installments.any((i) => i.paidAmount > 0);
          if (loan.loanType == 'qarz' && loan.termMonths >= 12 && loan.termMonths % 12 == 0 && loan.installmentAmount != loan.principal ~/ (11 * (loan.termMonths ~/ 12))) {
            _manualInstallment.text = loan.installmentAmount.toString();
          }
        });
      }
    } catch (_) {}
    if (mounted) setState(() { _isLoading = false; _loaded = true; });
  }

  @override
  void dispose() { for (final c in [_name, _principal, _rate, _term, _installment, _fee, _serviceFee, _manualInstallment, _dueDay, _facility, _paymentLink]) { c.dispose(); } super.dispose(); }

  int? get _principalValue => parseInt(_principal.text);
  int? get _termValue => parseInt(_term.text);
  int? get _serviceFeeValue { final text = _serviceFee.text.trim(); return text.isEmpty ? null : parseInt(text); }
  int? get _manualValue { if (_loanType != 'qarz') return null; final text = _manualInstallment.text.trim(); return text.isEmpty ? null : parseInt(text); }

  double? _parsePercent(String text) {
    final cleaned = normalizeDigits(text).replaceAll('٫', '.').replaceAll(',', '.').trim();
    return double.tryParse(cleaned);
  }

  int? _reverseRateBp() {
    final p = _principalValue; final t = _termValue; final i = parseInt(_installment.text);
    if (p == null || t == null || i == null || p <= 0 || t <= 0 || i <= 0) return null;
    try { return InterestCalculator.findAnnualRateBpForInstallment(principal: p, termMonths: t, targetInstallment: i); } catch (_) { return null; }
  }

  int? get _rateBp {
    if (_loanType != 'normal') return null;
    if (_reverseCalc) return _reverseRateBp();
    final percent = _parsePercent(_rate.text);
    if (percent == null || percent < 0) return null;
    return (percent * 100).round();
  }

  CalcBResult? _safePreview() {
    if (_loanType != 'normal') return null;
    final p = _principalValue; final bp = _rateBp; final t = _termValue;
    if (p == null || p <= 0 || bp == null || t == null || t <= 0) return null;
    try { return InterestCalculator.calcB(principal: p, annualRateBp: bp, term: t); } catch (_) { return null; }
  }

  QarzAlHasanehResult? _safeQarzPreview() {
    if (_loanType != 'qarz') return null;
    final p = _principalValue; final f = parseInt(_fee.text); final t = _termValue;
    if (p == null || p <= 0 || f == null || f < 0 || t == null || t < 12 || t % 12 != 0) return null;
    try { return InterestCalculator.calcQarzAlHasaneh(principal: p, termMonths: t, feeAmount: f, manualInstallment: _manualValue); } catch (_) { return null; }
  }

  String? _effectiveRateText({required int totalInterest}) {
    final p = _principalValue; final t = _termValue;
    if (p == null || p <= 0 || t == null || t <= 0) return null;
    try {
      final bp = InterestCalculator.effectiveRateBpWithFee(principal: p, term: t, totalInterest: totalInterest, serviceFee: _serviceFeeValue ?? 0);
      return '${(bp / 100).toStringAsFixed(2)}٪';
    } catch (_) { return null; }
  }

  String? _validateTerm(String? v) {
    final t = parseInt(v ?? ''); if (t == null || t <= 0) return 'نامعتبر';
    if (_loanType == 'qarz' && (t < 12 || t % 12 != 0)) return 'برای قرض‌الحسنه تعداد اقساط باید مضرب ۱۲ باشد (هر سال: ۱۱ ماه اصل + ۱ ماه کارمزد)';
    return null;
  }

  String? _validateManualInstallment(String? v) {
    if (v == null || v.trim().isEmpty) return null;
    final m = parseInt(v); if (m == null || m <= 0) return 'نامعتبر';
    final p = _principalValue; final t = _termValue;
    if (p != null && t != null && t >= 12 && t % 12 == 0) {
      final principalMonths = 11 * (t ~/ 12);
      if (p - m * (principalMonths - 1) <= 0) return 'قسط دستی برای این اصل و مدت بیش از حد بزرگ است';
    }
    return null;
  }

  String? _validateServiceFee(String? v) { if (v == null || v.trim().isEmpty) return null; final f = parseInt(v); if (f == null || f < 0) return 'نامعتبر'; return null; }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedBank == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لطفاً بانک را انتخاب کنید'))); return; }
    if (_firstDueDate == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لطفاً تاریخ اولین قسط را انتخاب کنید'))); return; }

    setState(() => _isLoading = true);
    final messenger = ScaffoldMessenger.of(context); final router = GoRouter.of(context);
    final principal = parseInt(_principal.text)!; final term = parseInt(_term.text)!; final dueDay = parseInt(_dueDay.text)!;
    final rateBp = _loanType == 'normal' ? (_rateBp ?? 0) : null;
    final fee = _loanType == 'qarz' ? (parseInt(_fee.text) ?? 0) : null;
    final manual = _manualValue; final serviceFee = _serviceFeeValue;
    final facility = _facility.text.isEmpty ? null : _facility.text; final paymentLink = _paymentLink.text.isEmpty ? null : _paymentLink.text;

    try {
      if (widget.isEditMode) {
        final ok = await ref.read(updateLoanProvider.notifier).submit(loanId: widget.loanId!, name: _name.text.trim(), bankName: _selectedBank!, principal: principal, annualRateBp: rateBp, feeAmount: fee, loanType: _loanType, termMonths: term, firstDueDate: _firstDueDate!, dueDayOfMonth: dueDay, facilityNumber: facility, paymentLink: paymentLink, manualInstallment: manual, serviceFee: serviceFee);
        if (ok) { messenger.showSnackBar(const SnackBar(content: Text('ویرایش شد'))); router.pop(); } else { messenger.showSnackBar(const SnackBar(content: Text('خطا در ویرایش وام'))); }
      } else {
        final loanId = await ref.read(createLoanProvider.notifier).submit(name: _name.text.trim(), bankName: _selectedBank!, principal: principal, annualRateBp: rateBp, feeAmount: fee, loanType: _loanType, termMonths: term, firstDueDate: _firstDueDate!, dueDayOfMonth: dueDay, facilityNumber: facility, paymentLink: paymentLink, manualInstallment: manual, serviceFee: serviceFee);
        if (loanId != null) { messenger.showSnackBar(const SnackBar(content: Text('ذخیره شد'))); router.pushReplacementNamed(AppRoutes.loanDetail, pathParameters: {'id': loanId}); } else { messenger.showSnackBar(const SnackBar(content: Text('خطا در ذخیره وام'))); }
      }
    } catch (e) { messenger.showSnackBar(SnackBar(content: Text('خطا: $e'))); } finally { if (mounted) setState(() => _isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isEditMode && !_loaded) return Scaffold(appBar: AppBar(leading: const AppBackButton(), title: const Text('ویرایش وام')), body: const Center(child: CircularProgressIndicator()));
    final preview = _safePreview(); final qarzPreview = _safeQarzPreview(); final reverseRateBp = _reverseCalc ? _reverseRateBp() : null;

    return Scaffold(
      appBar: AppBar(leading: const AppBackButton(), title: Text(widget.isEditMode ? 'ویرایش وام' : 'افزودن وام')),
      body: Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
        if (_hasPayments) const Card(color: Colors.redAccent, child: Padding(padding: EdgeInsets.all(12), child: Text('به دلیل وجود پرداختی، اصل و مدت قابل ویرایش نیست.', style: TextStyle(color: Colors.white)))),
        const SizedBox(height: 16),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'normal', label: Text('وام عادی')), ButtonSegment(value: 'qarz', label: Text('قرض‌الحسنه'))], selected: {_loanType}, onSelectionChanged: _hasPayments ? null : (v) => setState(() => _loanType = v.first)),
        const SizedBox(height: 16),
        TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'عنوان وام', border: OutlineInputBorder()), validator: (v) => (v == null || v.isEmpty) ? 'الزامی' : null),
        const SizedBox(height: 16),
        BankAutocompleteField(initialValue: _selectedBank, onSelected: (v) => setState(() => _selectedBank = v), validator: (_) => _selectedBank == null ? 'الزامی' : null),
        BankLogoPreview(bankName: _selectedBank),
        const SizedBox(height: 16),
        TextFormField(controller: _principal, enabled: !_hasPayments, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ اصل وام (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
        const SizedBox(height: 16),
        TextFormField(controller: _term, enabled: !_hasPayments, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: InputDecoration(labelText: 'تعداد اقساط (ماه)', helperText: _loanType == 'qarz' ? 'مضرب ۱۲؛ هر سال: ۱۱ ماه اصل + ۱ ماه کارمزد' : null, border: const OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateTerm),
        const SizedBox(height: 16),
        if (_loanType == 'normal') ...[
          SwitchListTile(title: const Text('محاسبه نرخ از روی مبلغ قسط'), value: _reverseCalc, onChanged: (v) => setState(() => _reverseCalc = v)),
          if (_reverseCalc) ...[
            TextFormField(controller: _installment, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ قسط (تومان)', border: OutlineInputBorder()), onChanged: (_) { final bp = _reverseRateBp(); setState(() { if (bp != null) _rate.text = (bp / 100).toStringAsFixed(2); }); }, validator: (_) => _reverseRateBp() == null ? 'نامعتبر' : null),
            if (reverseRateBp != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('نرخ سود محاسبه‌شده: ${(reverseRateBp / 100).toStringAsFixed(2)}٪', style: TextStyle(color: Theme.of(context).colorScheme.primary))),
            const SizedBox(height: 16),
          ] else ...[
            TextFormField(controller: _rate, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'نرخ سود سالانه (%)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => _parsePercent(v ?? '') == null ? 'نامعتبر' : null),
            const SizedBox(height: 16),
          ],
        ] else ...[
          TextFormField(controller: _fee, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ کل کارمزد (تومان)', helperText: 'بین سال‌ها به‌صورت نزولی تقسیم می‌شود', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
          const SizedBox(height: 16),
          TextFormField(controller: _manualInstallment, enabled: !_hasPayments, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ قسط ماهانه (دستی)', helperText: 'اختیاری؛ اگر خالی بماند، اصل بر (۱۱ × تعداد سال) تقسیم می‌شود', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateManualInstallment),
          const SizedBox(height: 16),
        ],
        TextFormField(controller: _serviceFee, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'کارمزد خدمات بانکی (تومان)', helperText: 'اختیاری؛ در نرخ مؤثر لحاظ می‌شود', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateServiceFee),
        const SizedBox(height: 16),
        JalaliDatePicker(label: 'تاریخ اولین قسط', initialDate: _firstDueDate, onChanged: (v) => setState(() => _firstDueDate = v), validator: (_) => _firstDueDate == null ? 'الزامی' : null),
        const SizedBox(height: 16),
        TextFormField(controller: _dueDay, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: const InputDecoration(labelText: 'روز سررسید در ماه (1-31)', border: OutlineInputBorder()), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
        const SizedBox(height: 24),
        if (preview != null) _previewCard(['قسط ماهانه: ${_money.format(preview.installment)} تومان', 'کل بازپرداخت: ${_money.format(preview.totalReturn)} تومان', if (_serviceFeeValue != null && _serviceFeeValue! > 0) 'کارمزد خدمات بانکی: ${_money.format(_serviceFeeValue!)} تومان', if (_effectiveRateText(totalInterest: preview.totalInterest) != null) 'نرخ مؤثر (با کارمزد): ${_effectiveRateText(totalInterest: preview.totalInterest)}']),
        if (qarzPreview != null) _previewCard(['قسط ماهانه اصل: ${_money.format(qarzPreview.monthlyPrincipalInstallment)} تومان (${qarzPreview.principalMonths} ماه)', if (qarzPreview.lastPrincipalInstallment != qarzPreview.monthlyPrincipalInstallment) 'آخرین قسط اصل: ${_money.format(qarzPreview.lastPrincipalInstallment)} تومان', for (var k = 0; k < qarzPreview.yearlyFees.length; k++) 'کارمزد سال ${k + 1} (ماه ${12 * k + 1}): ${_money.format(qarzPreview.yearlyFees[k])} تومان', 'کل بازپرداخت: ${_money.format(qarzPreview.totalReturn)} تومان', if (_serviceFeeValue != null && _serviceFeeValue! > 0) 'کارمزد خدمات بانکی: ${_money.format(_serviceFeeValue!)} تومان', if (_effectiveRateText(totalInterest: qarzPreview.totalFee) != null) 'نرخ مؤثر (با کارمزد): ${_effectiveRateText(totalInterest: qarzPreview.totalFee)}']),
        const SizedBox(height: 24),
        Card(child: ExpansionTile(title: const Text('بیشتر (شماره تسهیلات و لینک پرداخت)'), children: [Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextFormField(controller: _facility, decoration: const InputDecoration(labelText: 'شماره تسهیلات', border: OutlineInputBorder())), const SizedBox(height: 12), TextFormField(controller: _paymentLink, decoration: const InputDecoration(labelText: 'لینک پرداخت', border: OutlineInputBorder()))]))])),
        const SizedBox(height: 32),
        FilledButton(onPressed: _isLoading ? null : _save, child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: _isLoading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(widget.isEditMode ? 'ذخیره تغییرات' : 'ثبت وام', style: const TextStyle(fontSize: 16)))),
        const SizedBox(height: 32),
      ])),
    );
  }

  Widget _previewCard(List<String> lines) {
    return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final line in lines) Text(line)])));
  }
}

import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/data/iranian_banks.dart';
import 'package:loan_manager/core/router/app_router.dart';
import 'package:loan_manager/features/export/data/export_data.dart';
import 'package:loan_manager/features/export/data/excel_export_service.dart';
import 'package:loan_manager/features/export/data/pdf_export_service.dart';
import 'package:loan_manager/features/import/data/excel_import_service.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:loan_manager/features/ledger/presentation/ledger_providers.dart';
import 'package:loan_manager/shared/widgets/jalali_date_range_dialog.dart';
import 'package:share_plus/share_plus.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

class LoanListScreen extends ConsumerStatefulWidget {
  const LoanListScreen({super.key});

  @override
  ConsumerState<LoanListScreen> createState() => _LoanListScreenState();
}

class _LoanListScreenState extends ConsumerState<LoanListScreen> {
  bool _selectionMode = false;
  final Set<String> _selected = {};
  bool _busy = false;

  /// Optimistic order shown right after a drop, until the database stream catches up.
  List<Loan>? _pendingOrder;

  void _toast(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  void _enterSelectionMode(String id) {
    setState(() {
      _selectionMode = true;
      _selected.add(id);
    });
  }

  void _toggle(String id) {
    setState(() {
      if (!_selected.remove(id)) _selected.add(id);
    });
  }

  void _exitSelectionMode() {
    setState(() {
      _selectionMode = false;
      _selected.clear();
    });
  }

  DateRangeFilter? _toFilter(JalaliDateRange? range) =>
      range == null || range.isEmpty ? null : DateRangeFilter(from: range.from, to: range.to);

  /// Selected loans when selecting, otherwise every active loan.
  List<String> _exportTargetIds() {
    if (_selected.isNotEmpty) return _selected.toList();
    final all = ref.read(activeLoansProvider).value ?? const <Loan>[];
    return [for (final l in all) l.id];
  }

  Future<void> _exportExcel() async {
    final ids = _exportTargetIds();
    if (ids.isEmpty) {
      _toast('وامی برای خروجی وجود ندارد');
      return;
    }
    final range = await showJalaliDateRangeDialog(context);
    if (range == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final path = await ref.read(excelExportServiceProvider).export(loanIds: ids, range: _toFilter(range));
      if (!mounted) return;
      await SharePlus.instance.share(ShareParams(files: [XFile(path)], text: 'خروجی اکسل وام‌ها'));
      if (mounted) _toast('خروجی اکسل ساخته شد');
    } catch (e) {
      if (mounted) _toast('خطا در خروجی اکسل: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _exportPdf() async {
    final range = await showJalaliDateRangeDialog(context);
    if (range == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final shared = await ref.read(pdfExportServiceProvider).share(loanIds: _selected.toList(), range: _toFilter(range));
      if (mounted) _toast(shared ? 'فایل PDF آماده اشتراک‌گذاری است' : 'ارسال فایل PDF انجام نشد');
    } catch (e) {
      if (mounted) _toast('خطا در خروجی PDF: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _importExcel() async {
    final files = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (files.isEmpty || !mounted) return;
    final Uint8List bytes;
    try {
      bytes = await files.first.readAsBytes(); // Safe on Android 13+ (no raw file path access)
    } catch (_) {
      if (mounted) _toast('خواندن فایل ممکن نبود');
      return;
    }
    if (bytes.isEmpty) {
      _toast('خواندن فایل ممکن نبود');
      return;
    }
    if (!mounted) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('ورود از اکسل'),
        content: const Text('وام‌ها، اقساط و پرداخت‌های فایل به برنامه اضافه می‌شوند. ادامه می‌دهید؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ورود')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _busy = true);
    try {
      final summary = await ref.read(excelImportServiceProvider).importBytes(bytes);
      if (mounted) _toast(summary.report);
    } catch (e) {
      if (mounted) _toast('خطا در ورود: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _deleteSelected() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => const _DeleteConfirmDialog(),
    );
    if (confirmed != true || !mounted) return;

    final ids = _selected.toList();
    setState(() => _busy = true);
    var failed = 0;
    try {
      for (final id in ids) {
        final ok = await ref.read(deleteLoanProvider.notifier).submit(id);
        if (!ok) failed++;
        if (!mounted) return;
      }
    } catch (_) {
      failed = ids.length;
    } finally {
      if (mounted) setState(() => _busy = false);
    }
    if (!mounted) return;
    _exitSelectionMode();
    _toast(failed == 0 ? 'وام(های) انتخاب شده حذف شد' : 'حذف $failed وام ناموفق بود');
  }

  Future<void> _onReorder(List<Loan> current, int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    if (oldIndex == newIndex) return;
    final reordered = List<Loan>.of(current);
    reordered.insert(newIndex, reordered.removeAt(oldIndex));
    setState(() => _pendingOrder = reordered);
    final ok = await ref.read(reorderLoansProvider.notifier).submit([for (final l in reordered) l.id]);
    if (!mounted) return;
    setState(() => _pendingOrder = null);
    if (!ok) _toast('ذخیره ترتیب جدید ناموفق بود');
  }

  Widget _buildHeader() {
    final theme = Theme.of(context);
    if (_selectionMode) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Row(
          children: [
            IconButton(icon: const Icon(Icons.close_rounded), tooltip: 'خروج از انتخاب', onPressed: _exitSelectionMode),
            const SizedBox(width: 4),
            Expanded(child: Text('${_selected.length} مورد انتخاب شده', style: theme.textTheme.titleMedium)),
          ],
        ),
      );
    }
    final compact = OutlinedButton.styleFrom(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      visualDensity: VisualDensity.compact,
    );
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : _exportExcel,
                  style: compact,
                  icon: const Icon(Icons.download_rounded, size: 20),
                  label: const Text('خروجی اکسل'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : _importExcel,
                  style: compact,
                  icon: const Icon(Icons.upload_file_rounded, size: 20),
                  label: const Text('ورود از اکسل'),
                ),
              ),
            ],
          ),
          if (_busy) ...[
            const SizedBox(height: 12),
            const LinearProgressIndicator(),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final loansAsync = ref.watch(activeLoansProvider);
    final theme = Theme.of(context);

    return PopScope(
      canPop: !_selectionMode,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _exitSelectionMode();
      },
      child: Scaffold(
        floatingActionButton: _selectionMode || _busy
            ? null
            : FloatingActionButton.extended(
                onPressed: () => context.pushNamed(AppRoutes.addLoan),
                icon: const Icon(Icons.add),
                label: const Text('افزودن وام'),
              ),
        bottomNavigationBar: _selectionBar,
        body: loansAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(child: Text('خطا در بارگذاری وام‌ها\n$error', textAlign: TextAlign.center, style: TextStyle(color: theme.colorScheme.error))),
          data: (data) {
            if (data.isEmpty) {
              return Column(
                children: [
                  Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 0), child: _buildHeader()),
                  const Expanded(child: Center(child: Text('وامی یافت نشد'))),
                ],
              );
            }
            final loans = _pendingOrder ?? data;
            return ReorderableListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              buildDefaultDragHandles: false,
              header: _buildHeader(),
              itemCount: loans.length,
              onReorder: (oldIndex, newIndex) => _onReorder(loans, oldIndex, newIndex),
              itemBuilder: (context, index) {
                final loan = loans[index];
                return Padding(
                  key: ValueKey(loan.id),
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _LoanCard(
                    loan: loan,
                    index: index,
                    selectionMode: _selectionMode,
                    selected: _selected.contains(loan.id),
                    onTap: () => _selectionMode ? _toggle(loan.id) : context.pushNamed(AppRoutes.loanDetail, pathParameters: {'id': loan.id}),
                    onLongPress: () => _enterSelectionMode(loan.id),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }

  Widget get _selectionBar {
    if (!_selectionMode || _selected.isEmpty || _busy) return const SizedBox.shrink();
    final scheme = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _exportExcel,
                icon: const Icon(Icons.table_chart_rounded),
                label: const Text('خروجی اکسل'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.tonalIcon(
                onPressed: _exportPdf,
                icon: const Icon(Icons.picture_as_pdf_rounded),
                label: const Text('خروجی PDF'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                onPressed: _deleteSelected,
                style: FilledButton.styleFrom(backgroundColor: scheme.error, foregroundColor: scheme.onError),
                icon: const Icon(Icons.delete_rounded),
                label: const Text('حذف'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Confirmation dialog: the delete button only becomes active once the user typed «حذف».
class _DeleteConfirmDialog extends StatefulWidget {
  const _DeleteConfirmDialog();

  @override
  State<_DeleteConfirmDialog> createState() => _DeleteConfirmDialogState();
}

class _DeleteConfirmDialogState extends State<_DeleteConfirmDialog> {
  static const String _keyword = 'حذف';
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final matches = _controller.text.trim() == _keyword;
    return AlertDialog(
      title: const Text('حذف وام'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('آیا از حذف وام(های) انتخاب شده مطمئن هستید؟'),
          const SizedBox(height: 16),
          TextField(
            controller: _controller,
            autofocus: true,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              labelText: 'برای تایید، کلمه «حذف» را تایپ کنید',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
        FilledButton(
          onPressed: matches ? () => Navigator.pop(context, true) : null,
          style: FilledButton.styleFrom(backgroundColor: scheme.error, foregroundColor: scheme.onError),
          child: const Text('حذف'),
        ),
      ],
    );
  }
}

class _LoanCard extends ConsumerWidget {
  const _LoanCard({
    required this.loan,
    required this.index,
    required this.selectionMode,
    required this.selected,
    required this.onTap,
    required this.onLongPress,
  });

  final Loan loan;
  final int index;
  final bool selectionMode;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onLongPress;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final installments = ref.watch(loanInstallmentsProvider(loan.id));
    final total = installments.value?.length ?? loan.termMonths;
    final paid = installments.value?.where((i) => i.isFullyPaid).length ?? 0;
    final progress = total == 0 ? 0.0 : paid / total;
    final logoPath = IranianBanks.logoAssetFor(loan.bankName ?? '');

    return Card(
      clipBehavior: Clip.antiAlias,
      color: selected ? theme.colorScheme.primaryContainer.withValues(alpha: 0.3) : null,
      child: InkWell(
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (selectionMode) ...[
                    Checkbox(value: selected, onChanged: (_) => onTap()),
                    const SizedBox(width: 8),
                  ],
                  Expanded(child: Text(loan.name, style: theme.textTheme.titleMedium, maxLines: 1, overflow: TextOverflow.ellipsis)),
                  IconButton(icon: const Icon(Icons.edit, size: 20), onPressed: () => context.push('/edit-loan/${loan.id}')),
                  if (!selectionMode)
                    ReorderableDragStartListener(
                      index: index,
                      child: Semantics(
                        label: 'جابجایی',
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Icon(Icons.drag_indicator, color: theme.colorScheme.onSurfaceVariant),
                        ),
                      ),
                    ),
                ],
              ),
              if (loan.bankName != null && loan.bankName!.isNotEmpty)
                Row(
                  children: [
                    if (logoPath != null)
                      SvgPicture.asset(logoPath, width: 24, height: 24)
                    else
                      const Icon(Icons.account_balance_rounded, size: 24),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        loan.bankName!,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                      ),
                    ),
                  ],
                ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('مبلغ قسط', style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                  Text('${_money.format(loan.installmentAmount)} تومان', style: theme.textTheme.titleSmall),
                ],
              ),
              const SizedBox(height: 16),
              LinearProgressIndicator(value: progress, minHeight: 8, borderRadius: BorderRadius.circular(8)),
              const SizedBox(height: 8),
              Text('$paid از $total قسط پرداخت شده', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            ],
          ),
        ),
      ),
    );
  }
}

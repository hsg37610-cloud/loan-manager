import 'package:flutter_test/flutter_test.dart';
import 'package:loan_manager/core/finance/schedule_generator.dart';
import 'package:shamsi_date/shamsi_date.dart';

void main() {
  List<int> daysOf(List<ScheduleItem> s) =>
      s.map((e) => Jalali.fromDateTime(DateTime.parse(e.dueDate)).day).toList();

  test('12 months from Farvardin 31, 1403 clamps correctly', () {
    final s = ScheduleGenerator.generate(
      principal: 120000000,
      totalInterest: 24200000,
      termMonths: 12,
      firstDueDate: Jalali(1403, 1, 31).toDateTime(),
      dueDayOfMonth: 31,
    );
    expect(s.length, 12);
    expect(s[0].dueDate, '2024-04-19');
    expect(s[1].dueDate, '2024-05-20');
    // ماه ۱ تا ۶: ۳۱ روز، ماه ۷ تا ۱۲: ۳۰ روز
    expect(daysOf(s), [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 30]);
  });

  test('crossing a non-leap Esfand (29 days) into 1405', () {
    final s = ScheduleGenerator.generate(
      principal: 120000000,
      totalInterest: 24200000,
      termMonths: 12,
      firstDueDate: Jalali(1404, 7, 30).toDateTime(),
      dueDayOfMonth: 31,
    );
    expect(daysOf(s), [30, 30, 30, 30, 30, 29, 31, 31, 31, 31, 31, 31]);
  });

  test('sum equals total return; last absorbs rounding', () {
    final s = ScheduleGenerator.generate(
      principal: 120000000,
      totalInterest: 24200000,
      termMonths: 12,
      firstDueDate: Jalali(1403, 1, 31).toDateTime(),
      dueDayOfMonth: 31,
    );
    expect(s.fold<int>(0, (a, e) => a + e.amount), 144200000);
    expect(s.first.amount, 12016667);
    expect(s.last.amount, 12016663);
    expect(s.map((e) => e.installmentNumber), List.generate(12, (i) => i + 1));
  });

  group('generateQarzAlHasaneh', () {
    List<ScheduleItem> qarz({int principal = 100000000, int fee = 500000, int term = 12, int? manual}) =>
        ScheduleGenerator.generateQarzAlHasaneh(
          principal: principal,
          feeAmount: fee,
          termMonths: term,
          firstDueDate: Jalali(1405, 1, 15).toDateTime(),
          dueDayOfMonth: 15,
          manualInstallment: manual,
        );

    test('remainder goes to the last principal installment, fee is the last installment', () {
      final s = qarz();
      expect(s.length, 12);
      expect(s[0].amount, 9090909);
      expect(s[9].amount, 9090909);
      expect(s[10].amount, 9090910); // 9090909 + remainder 1
      expect(s[11].amount, 500000);
      expect(s.take(11).fold<int>(0, (a, e) => a + e.amount), 100000000);
      expect(s.fold<int>(0, (a, e) => a + e.amount), 100500000);
    });

    test('manual installment replaces the calculated one, last principal installment absorbs the difference', () {
      final s = qarz(manual: 9100000);
      expect(s.take(10).every((e) => e.amount == 9100000), isTrue);
      expect(s[10].amount, 9000000);
      expect(s[11].amount, 500000); // fee stays the fee
      expect(s.fold<int>(0, (a, e) => a + e.amount), 100500000);
    });

    test('manual installment that leaves nothing for the last principal installment is rejected', () {
      expect(() => qarz(manual: 10000000), throwsArgumentError);
    });

    test('term below 2 is rejected', () {
      expect(() => qarz(term: 1), throwsArgumentError);
    });
  });
}

import 'package:flutter/material.dart';
import 'package:loan_manager/core/utils/input_utils.dart';
import 'package:loan_manager/core/utils/jalali_utils.dart';
import 'package:shamsi_date/shamsi_date.dart';

/// Read-only form field that opens [JalaliCalendarDialog]. Reports the chosen
/// day as a Gregorian [DateTime] through [onChanged].
class JalaliDatePicker extends StatefulWidget {
  final String label;
  final DateTime? initialDate;
  final ValueChanged<DateTime> onChanged;
  final String? Function(String?)? validator;

  const JalaliDatePicker({super.key, required this.label, required this.onChanged, this.initialDate, this.validator});

  @override
  State<JalaliDatePicker> createState() => _JalaliDatePickerState();
}

class _JalaliDatePickerState extends State<JalaliDatePicker> {
  late final TextEditingController _controller;
  DateTime? _selectedGregorianDate;

  @override
  void initState() {
    super.initState();
    _selectedGregorianDate = widget.initialDate;
    _controller = TextEditingController(text: _selectedGregorianDate != null ? JalaliUtils.formatFromDateTime(_selectedGregorianDate!) : '');
  }

  Future<void> _openPicker() async {
    final initial = _selectedGregorianDate != null ? Jalali.fromDateTime(_selectedGregorianDate!) : Jalali.now();
    final result = await showDialog<Jalali>(
      context: context,
      builder: (context) => JalaliCalendarDialog(initialDate: initial),
    );
    if (result == null || !mounted) return;
    final gregorian = result.toGregorian().toDateTime();
    setState(() {
      _selectedGregorianDate = gregorian;
      _controller.text = JalaliUtils.formatFromDateTime(gregorian);
    });
    widget.onChanged(gregorian);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: _controller,
      readOnly: true,
      validator: widget.validator,
      decoration: InputDecoration(labelText: widget.label, suffixIcon: const Icon(Icons.calendar_today), border: const OutlineInputBorder()),
      onTap: _openPicker,
    );
  }
}

const List<String> _monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const List<String> _weekdayLabels = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

/// Month-grid calendar dialog (Saturday-first). Pops with the chosen [Jalali]
/// date, or null when cancelled.
class JalaliCalendarDialog extends StatefulWidget {
  const JalaliCalendarDialog({super.key, required this.initialDate});
  final Jalali initialDate;

  @override
  State<JalaliCalendarDialog> createState() => _JalaliCalendarDialogState();
}

class _JalaliCalendarDialogState extends State<JalaliCalendarDialog> {
  static const int _minYear = 1300;
  static const int _maxYear = 1500;

  late int _year;
  late int _month;
  late Jalali _selected;
  final Jalali _today = Jalali.now();

  @override
  void initState() {
    super.initState();
    _year = widget.initialDate.year;
    _month = widget.initialDate.month;
    _selected = widget.initialDate;
  }

  void _shiftMonth(int delta) {
    final index = _year * 12 + (_month - 1) + delta;
    final year = index ~/ 12;
    if (year < _minYear || year > _maxYear) return;
    setState(() {
      _year = year;
      _month = index % 12 + 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final monthLength = Jalali(_year, _month, 1).monthLength;
    // weekDay: 1 = Saturday ... 7 = Friday, so this is the number of empty cells before day 1.
    final leadingBlanks = Jalali(_year, _month, 1).weekDay - 1;

    // The Persian calendar is always laid out right-to-left (Saturday on the right).
    return Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('انتخاب تاریخ'),
        contentPadding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
        content: SizedBox(
          width: 320,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  IconButton(tooltip: 'ماه قبل', icon: const Icon(Icons.chevron_right_rounded), onPressed: () => _shiftMonth(-1)),
                  Expanded(
                    child: Text(
                      '${_monthNames[_month - 1]} ${toPersianDigits(_year)}',
                      textAlign: TextAlign.center,
                      style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                  IconButton(tooltip: 'ماه بعد', icon: const Icon(Icons.chevron_left_rounded), onPressed: () => _shiftMonth(1)),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton.icon(
                    onPressed: () => _shiftMonth(-12),
                    icon: const Icon(Icons.keyboard_double_arrow_right_rounded, size: 18),
                    label: const Text('سال قبل'),
                  ),
                  TextButton.icon(
                    onPressed: () => _shiftMonth(12),
                    icon: const Icon(Icons.keyboard_double_arrow_left_rounded, size: 18),
                    iconAlignment: IconAlignment.end,
                    label: const Text('سال بعد'),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  for (final label in _weekdayLabels)
                    Expanded(
                      child: Center(
                        child: Text(
                          label,
                          style: theme.textTheme.labelMedium?.copyWith(color: label == 'ج' ? scheme.error : scheme.onSurfaceVariant, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              GridView.count(
                crossAxisCount: 7,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 2,
                crossAxisSpacing: 2,
                children: [
                  for (var i = 0; i < leadingBlanks; i++) const SizedBox.shrink(),
                  for (var day = 1; day <= monthLength; day++) _dayCell(theme, day),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.of(context).pop(_selected), child: const Text('تایید')),
        ],
      ),
    );
  }

  Widget _dayCell(ThemeData theme, int day) {
    final scheme = theme.colorScheme;
    final isSelected = _selected.year == _year && _selected.month == _month && _selected.day == day;
    final isToday = _today.year == _year && _today.month == _month && _today.day == day;
    return InkResponse(
      onTap: () => setState(() => _selected = Jalali(_year, _month, day)),
      radius: 22,
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: isSelected ? scheme.primary : null,
          border: isToday && !isSelected ? Border.all(color: scheme.primary) : null,
        ),
        child: Text(
          toPersianDigits(day),
          style: theme.textTheme.bodyMedium?.copyWith(
            color: isSelected ? scheme.onPrimary : scheme.onSurface,
            fontWeight: isSelected || isToday ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}

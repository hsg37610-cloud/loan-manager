import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppBackButton extends StatelessWidget {
  const AppBackButton({super.key});
  @override
  Widget build(BuildContext context) {
    final rtl = Directionality.of(context) == TextDirection.rtl;
    return IconButton(
      tooltip: 'بازگشت',
      icon: Icon(rtl ? Icons.arrow_forward_rounded : Icons.arrow_back_rounded),
      onPressed: () {
        if (context.canPop()) { context.pop(); } else { context.go('/'); }
      },
    );
  }
}

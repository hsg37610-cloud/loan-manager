import 'package:flutter/material.dart';
import 'package:loan_manager/core/widgets/app_drawer.dart';
import 'package:loan_manager/shared/widgets/app_back_button.dart';

class MainScaffold extends StatelessWidget {
  final Widget child;
  final String location;
  const MainScaffold({super.key, required this.child, required this.location});

  bool get _isDashboard => location == '/';

  String _titleFor(String location) {
    switch (location) {
      case '/': return 'داشبورد';
      case '/calculator': return 'محاسبه‌گر وام';
      case '/installments': return 'اقساط';
      case '/loans': return 'وام‌های من';
      case '/settings': return 'تنظیمات';
      default: return 'مدیریت وام من';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titleFor(location)),
        // RTL: hamburger on the right (leading), back button on the left (actions).
        leading: _isDashboard ? null : Builder(builder: (ctx) => IconButton(icon: const Icon(Icons.menu_rounded), onPressed: () => Scaffold.of(ctx).openDrawer())),
        actions: _isDashboard ? null : const [AppBackButton()],
      ),
      drawer: const AppDrawer(),
      body: child,
    );
  }
}

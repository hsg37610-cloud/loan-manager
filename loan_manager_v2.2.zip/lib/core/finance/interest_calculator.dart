import 'finance_math.dart';

class CalcAResult {
  final int totalReturn; final int effectiveRateBp;
  const CalcAResult(this.totalReturn, this.effectiveRateBp);
}
class CalcBResult {
  final int totalInterest; final int totalReturn; final int installment;
  const CalcBResult(this.totalInterest, this.totalReturn, this.installment);
}
class CalcCResult {
  final int effectiveRateBp; final int approxInstallment;
  const CalcCResult(this.effectiveRateBp, this.approxInstallment);
}

class InterestCalculator {
  static int? findAnnualRateBpForInstallment({required int principal, required int termMonths, required int targetInstallment, int maxRateBp = 10000, int maxIterations = 60}) {
    if (termMonths <= 0 || principal <= 0) return null;
    int low = 0, high = maxRateBp, bestRate = 0, bestDiff = 1 << 30;
    for (int i = 0; i < maxIterations && low <= high; i++) {
      final mid = (low + high) ~/ 2;
      final result = calcB(principal: principal, annualRateBp: mid, term: termMonths);
      final diff = (result.installment - targetInstallment).abs();
      if (diff < bestDiff) { bestDiff = diff; bestRate = mid; }
      if (result.installment == targetInstallment) { return mid; } else if (result.installment < targetInstallment) { low = mid + 1; } else { high = mid - 1; }
    }
    return bestRate;
  }
  InterestCalculator._();
  static void _check(int principal, int term) { if (principal <= 0) throw ArgumentError('Principal must be > 0'); if (term <= 0) throw ArgumentError('Term must be > 0'); }
  static CalcAResult calcA({required int principal, required int term, required int installment}) {
    _check(principal, term); if (installment < 0) throw ArgumentError('Installment must be >= 0');
    final d = term * installment; final e = roundDiv(240000 * (d - principal), principal * (term + 1));
    return CalcAResult(d, e);
  }
  static CalcBResult calcB({required int principal, required int annualRateBp, required int term}) {
    _check(principal, term); if (annualRateBp < 0) throw ArgumentError('Rate must be >= 0');
    final j = roundDiv(principal * annualRateBp * (term + 1), 240000); final total = j + principal;
    return CalcBResult(j, total, roundDiv(total, term));
  }
  static int effectiveRateBpWithFee({required int principal, required int term, required int totalInterest, int serviceFee = 0}) {
    _check(principal, term); if (totalInterest < 0 || serviceFee < 0) throw ArgumentError('Cost must be >= 0');
    return roundDiv(240000 * (totalInterest + serviceFee), principal * (term + 1));
  }
  static List<int> qarzYearlyFees({required int totalFee, required int years}) {
    if (years < 1) throw ArgumentError('Years must be >= 1'); if (totalFee < 0) throw ArgumentError('Fee must be >= 0');
    final weightSum = years * (years + 1) ~/ 2;
    final fees = [for (var k = 1; k <= years; k++) totalFee * (years - k + 1) ~/ weightSum];
    fees[0] += totalFee - fees.fold<int>(0, (a, b) => a + b);
    return fees;
  }
  static QarzAlHasanehResult calcQarzAlHasaneh({required int principal, required int termMonths, required int feeAmount, int? manualInstallment}) {
    if (principal <= 0) throw ArgumentError('Principal must be > 0');
    if (termMonths < 12 || termMonths % 12 != 0) throw ArgumentError('Term must be a multiple of 12 for qarz-al-hasaneh');
    if (feeAmount < 0) throw ArgumentError('Fee must be >= 0');
    if (manualInstallment != null && manualInstallment <= 0) throw ArgumentError('Manual installment must be > 0');
    final years = termMonths ~/ 12; final principalMonths = 11 * years;
    final monthlyPrincipal = manualInstallment ?? principal ~/ principalMonths;
    final remainder = principal - (monthlyPrincipal * principalMonths); final lastPrincipal = monthlyPrincipal + remainder;
    if (lastPrincipal <= 0) throw ArgumentError('Manual installment is too large for this principal and term');
    return QarzAlHasanehResult(years: years, principalMonths: principalMonths, totalFee: feeAmount, totalReturn: principal + feeAmount, monthlyPrincipalInstallment: monthlyPrincipal, lastPrincipalInstallment: lastPrincipal, yearlyFees: qarzYearlyFees(totalFee: feeAmount, years: years));
  }
  static CalcCResult calcC({required int term, required int loan, required int totalReturn}) {
    _check(loan, term); final r = roundDiv(240000 * (totalReturn - loan), loan * (term + 1)); return CalcCResult(r, roundDiv(totalReturn, term));
  }
}

class QarzAlHasanehResult {
  final int years; final int principalMonths; final int totalFee; final int totalReturn;
  final int monthlyPrincipalInstallment; final int lastPrincipalInstallment; final List<int> yearlyFees;
  const QarzAlHasanehResult({required this.years, required this.principalMonths, required this.totalFee, required this.totalReturn, required this.monthlyPrincipalInstallment, required this.lastPrincipalInstallment, required this.yearlyFees});
}

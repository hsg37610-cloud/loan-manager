import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'tables.dart';

part 'app_database.g.dart';

String nowUtcIso() => DateTime.now().toUtc().toIso8601String();

@DriftDatabase(tables: [Loans, Installments, Payments, PaymentAllocations, LoanSettlements, InstallmentEvents])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());
  AppDatabase.forTesting(super.e);
  @override int get schemaVersion => 2;
  @override MigrationStrategy get migration => MigrationStrategy(
    onCreate: (m) => m.createAll(),
    onUpgrade: (m, from, to) async {
      if (from < 2) await _ensureSortOrderColumn();
    },
    beforeOpen: (details) async { await customStatement('PRAGMA foreign_keys = ON'); await _ensureServiceFeeColumn(); },
  );
  Future<void> _ensureSortOrderColumn() async {
    final columns = await customSelect('PRAGMA table_info(loans)').get();
    final exists = columns.any((row) => row.read<String>('name') == 'sort_order');
    if (!exists) await customStatement('ALTER TABLE loans ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0');
  }
  Future<void> _ensureServiceFeeColumn() async {
    final columns = await customSelect('PRAGMA table_info(loans)').get();
    final exists = columns.any((row) => row.read<String>('name') == 'service_fee');
    if (!exists) await customStatement('ALTER TABLE loans ADD COLUMN service_fee INTEGER');
  }
}
LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'loan_manager.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}

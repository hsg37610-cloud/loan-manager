import 'package:loan_manager/core/database/app_database_provider.dart';
import 'package:loan_manager/features/ledger/data/ledger_repository.dart';
import 'package:loan_manager/features/ledger/data/reminder_sync.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'ledger_providers.g.dart';

@Riverpod(keepAlive: true)
LedgerRepository ledgerRepository(Ref ref) => LedgerRepository(ref.watch(appDatabaseProvider));

@riverpod
Stream<List<Loan>> activeLoans(Ref ref) => ref.watch(ledgerRepositoryProvider).watchActiveLoans();

@riverpod
Stream<Loan?> loanById(Ref ref, String loanId) => ref.watch(ledgerRepositoryProvider).watchLoan(loanId);

@riverpod
Stream<List<Installment>> allInstallments(Ref ref) => ref.watch(ledgerRepositoryProvider).watchAllInstallments();

@riverpod
Stream<List<Installment>> loanInstallments(Ref ref, String loanId) => ref.watch(ledgerRepositoryProvider).watchInstallmentsForLoan(loanId);

@riverpod
Stream<List<Payment>> paymentsForLoan(Ref ref, String loanId) => ref.watch(ledgerRepositoryProvider).watchPaymentsForLoan(loanId);

@Riverpod(keepAlive: true)
class RecordPayment extends _$RecordPayment {
  @override
  FutureOr<void> build() {}
  Future<bool> submit({required String loanId, required int amount, required String date, String? note}) async {
    final repo = ref.read(ledgerRepositoryProvider); final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() async { await repo.recordPayment(loanId: loanId, amount: amount, date: date, note: note); await reminders.syncLoan(loanId); });
    if (!ref.mounted) return !result.hasError; state = result; return !result.hasError;
  }
}

@Riverpod(keepAlive: true)
class CreateLoan extends _$CreateLoan {
  @override
  FutureOr<String?> build() => null;
  Future<String?> submit({required String name, required String bankName, required int principal, required int? annualRateBp, required int? feeAmount, required String loanType, required int termMonths, required DateTime firstDueDate, required int dueDayOfMonth, String? facilityNumber, String? paymentLink, int? manualInstallment, int? serviceFee}) async {
    final repo = ref.read(ledgerRepositoryProvider); final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard<String?>(() async { final loanId = await repo.createLoan(name: name, bankName: bankName, principal: principal, annualRateBp: annualRateBp, feeAmount: feeAmount, loanType: loanType, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth, facilityNumber: facilityNumber, paymentLink: paymentLink, manualInstallment: manualInstallment, serviceFee: serviceFee); await reminders.syncLoan(loanId); return loanId; });
    if (!ref.mounted) return result.value; state = result; return result.value;
  }
}

@Riverpod(keepAlive: true)
class UpdateLoan extends _$UpdateLoan {
  @override
  FutureOr<void> build() {}
  Future<bool> submit({required String loanId, required String name, required String bankName, required int principal, required int? annualRateBp, required int? feeAmount, required String loanType, required int termMonths, required DateTime firstDueDate, required int dueDayOfMonth, String? facilityNumber, String? paymentLink, int? manualInstallment, int? serviceFee}) async {
    final repo = ref.read(ledgerRepositoryProvider); final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() async { final oldIds = (await repo.watchInstallmentsForLoan(loanId).first).map((i) => i.id).toList(); await repo.updateLoan(loanId: loanId, name: name, bankName: bankName, principal: principal, annualRateBp: annualRateBp, feeAmount: feeAmount, loanType: loanType, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth, facilityNumber: facilityNumber, paymentLink: paymentLink, manualInstallment: manualInstallment, serviceFee: serviceFee); await reminders.replaceForLoan(loanId, oldIds); });
    if (!ref.mounted) return !result.hasError; state = result; return !result.hasError;
  }
}

@Riverpod(keepAlive: true)
class DeleteLoan extends _$DeleteLoan {
  @override
  FutureOr<void> build() {}
  Future<bool> submit(String loanId) async {
    final repo = ref.read(ledgerRepositoryProvider); final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() async { await repo.softDeleteLoan(loanId); await reminders.syncLoan(loanId); });
    if (!ref.mounted) return !result.hasError; state = result; return !result.hasError;
  }
}

@Riverpod(keepAlive: true)
class ReorderLoans extends _$ReorderLoans {
  @override
  FutureOr<void> build() {}
  Future<bool> submit(List<String> orderedLoanIds) async {
    final repo = ref.read(ledgerRepositoryProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() => repo.updateLoansOrder(orderedLoanIds));
    if (!ref.mounted) return !result.hasError; state = result; return !result.hasError;
  }
}

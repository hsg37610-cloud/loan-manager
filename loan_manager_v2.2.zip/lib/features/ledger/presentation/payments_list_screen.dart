import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/utils/input_utils.dart';
import 'package:loan_manager/core/utils/jalali_utils.dart';
import 'package:loan_manager/features/ledger/data/reminder_sync.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:loan_manager/features/ledger/presentation/ledger_providers.dart';
import 'package:loan_manager/shared/widgets/app_back_button.dart';
import 'package:loan_manager/shared/widgets/jalali_date_picker.dart';
import 'package:share_plus/share_plus.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

/// Builds the text report for one or more payments (oldest first).
String buildPaymentsReport(Iterable<Payment> payments) {
  final sorted = payments.toList()..sort((a, b) => a.paymentDate.compareTo(b.paymentDate));
  final total = sorted.fold<int>(0, (sum, p) => sum + p.amount);
  final lines = [for (final p in sorted) '- ${JalaliUtils.formatJalali(p.paymentDate)}: ${_money.format(p.amount)} تومان'];
  return 'گزارش پرداخت‌ها:\n${lines.join('\n')}\nمجموع: ${_money.format(total)} تومان';
}

class PaymentsListScreen extends ConsumerStatefulWidget {
  const PaymentsListScreen({super.key, required this.loanId});
  final String loanId;

  @override
  ConsumerState<PaymentsListScreen> createState() => _PaymentsListScreenState();
}

class _PaymentsListScreenState extends ConsumerState<PaymentsListScreen> {
  final Set<String> _selected = {};

  void _toggle(String id) {
    setState(() {
      if (!_selected.remove(id)) _selected.add(id);
    });
  }

  void _toggleAll(List<Payment> payments) {
    setState(() {
      final allSelected = payments.isNotEmpty && payments.every((p) => _selected.contains(p.id));
      _selected.clear();
      if (!allSelected) _selected.addAll(payments.map((p) => p.id));
    });
  }

  Future<void> _share(Iterable<Payment> payments) async {
    if (payments.isEmpty) return;
    await SharePlus.instance.share(ShareParams(text: buildPaymentsReport(payments)));
  }

  void _toast(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _delete(Payment payment) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف پرداخت'),
        content: Text('پرداخت ${_money.format(payment.amount)} تومان حذف و مبلغ آن از اقساط کسر می‌شود. ادامه می‌دهید؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف')),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await ref.read(ledgerRepositoryProvider).deletePayment(payment.id);
      await ref.read(reminderSyncProvider).syncLoan(widget.loanId);
      if (!mounted) return;
      setState(() => _selected.remove(payment.id));
      _toast('پرداخت حذف شد');
    } catch (_) {
      if (mounted) _toast('حذف پرداخت ناموفق بود');
    }
  }

  Future<void> _edit(Payment payment) async {
    final result = await showDialog<_PaymentEdit>(
      context: context,
      builder: (context) => _EditPaymentDialog(payment: payment),
    );
    if (result == null || !mounted) return;
    try {
      await ref.read(ledgerRepositoryProvider).updatePayment(paymentId: payment.id, amount: result.amount, date: result.date, note: result.note);
      await ref.read(reminderSyncProvider).syncLoan(widget.loanId);
      if (mounted) _toast('پرداخت ویرایش شد');
    } catch (_) {
      if (mounted) _toast('ویرایش پرداخت ناموفق بود');
    }
  }

  @override
  Widget build(BuildContext context) {
    final paymentsAsync = ref.watch(paymentsForLoanProvider(widget.loanId));
    final payments = paymentsAsync.value ?? const <Payment>[];
    final selectedItems = payments.where((p) => _selected.contains(p.id)).toList();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(selectedItems.isEmpty ? 'پرداخت‌ها' : '${selectedItems.length} مورد انتخاب شده'),
        actions: [
          IconButton(
            tooltip: 'انتخاب همه',
            icon: const Icon(Icons.select_all_rounded),
            onPressed: payments.isEmpty ? null : () => _toggleAll(payments),
          ),
          if (selectedItems.isNotEmpty)
            IconButton(
              tooltip: 'اشتراک‌گذاری انتخاب‌شده‌ها',
              icon: const Icon(Icons.share_outlined),
              onPressed: () => _share(selectedItems),
            ),
          const AppBackButton(),
        ],
      ),
      body: paymentsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (_, _) => Center(child: Text('خطا در بارگذاری پرداخت‌ها', style: TextStyle(color: theme.colorScheme.error))),
        data: (items) {
          if (items.isEmpty) return const Center(child: Text('هنوز پرداختی ثبت نشده'));
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final payment = items[index];
              return _PaymentTile(
                payment: payment,
                selected: _selected.contains(payment.id),
                onToggle: () => _toggle(payment.id),
                onShare: () => _share([payment]),
                onEdit: () => _edit(payment),
                onDelete: () => _delete(payment),
              );
            },
          );
        },
      ),
    );
  }
}

class _PaymentTile extends StatelessWidget {
  const _PaymentTile({required this.payment, required this.selected, required this.onToggle, required this.onShare, required this.onEdit, required this.onDelete});
  final Payment payment;
  final bool selected;
  final VoidCallback onToggle;
  final VoidCallback onShare;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final note = payment.note;
    return Card(
      clipBehavior: Clip.antiAlias,
      color: selected ? theme.colorScheme.primaryContainer.withValues(alpha: 0.3) : null,
      child: InkWell(
        onTap: onToggle,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          child: Row(
            children: [
              Checkbox(value: selected, onChanged: (_) => onToggle()),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(JalaliUtils.formatJalali(payment.paymentDate), style: theme.textTheme.titleSmall),
                    if (note != null && note.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(note, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                    ],
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('${_money.format(payment.amount)} تومان', style: theme.textTheme.titleSmall),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _iconButton('اشتراک‌گذاری', Icons.share_outlined, onShare, null),
                      _iconButton('ویرایش', Icons.edit_outlined, onEdit, null),
                      _iconButton('حذف', Icons.delete_outline, onDelete, theme.colorScheme.error),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _iconButton(String tooltip, IconData icon, VoidCallback onPressed, Color? color) {
    return IconButton(
      tooltip: tooltip,
      icon: Icon(icon, size: 20, color: color),
      visualDensity: VisualDensity.compact,
      onPressed: onPressed,
    );
  }
}

class _PaymentEdit {
  const _PaymentEdit(this.amount, this.date, this.note);
  final int amount;
  final String date; // Gregorian yyyy-MM-dd
  final String? note;
}

class _EditPaymentDialog extends StatefulWidget {
  const _EditPaymentDialog({required this.payment});
  final Payment payment;

  @override
  State<_EditPaymentDialog> createState() => _EditPaymentDialogState();
}

class _EditPaymentDialogState extends State<_EditPaymentDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _amount = TextEditingController(text: _money.format(widget.payment.amount));
  late final TextEditingController _note = TextEditingController(text: widget.payment.note ?? '');
  late DateTime _date = DateTime.tryParse(widget.payment.paymentDate) ?? DateTime.now();

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final note = _note.text.trim();
    Navigator.pop(context, _PaymentEdit(parseInt(_amount.text)!, _date.toIso8601String().substring(0, 10), note.isEmpty ? null : note));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('ویرایش پرداخت'),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _amount,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.end,
                inputFormatters: const [NumericInputFormatter(thousands: true)],
                decoration: const InputDecoration(labelText: 'مبلغ پرداخت', suffixText: 'تومان'),
                validator: (value) {
                  final amount = parseInt(value ?? '');
                  return (amount == null || amount <= 0) ? 'مبلغ معتبر وارد کنید' : null;
                },
              ),
              const SizedBox(height: 16),
              JalaliDatePicker(label: 'تاریخ پرداخت', initialDate: _date, onChanged: (date) => _date = date),
              const SizedBox(height: 16),
              TextFormField(controller: _note, maxLines: 2, decoration: const InputDecoration(labelText: 'توضیحات (اختیاری)')),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')),
        FilledButton(onPressed: _submit, child: const Text('ذخیره')),
      ],
    );
  }
}

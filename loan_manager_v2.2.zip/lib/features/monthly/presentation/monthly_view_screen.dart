import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/utils/input_utils.dart';
import 'package:loan_manager/core/utils/jalali_utils.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:loan_manager/features/ledger/presentation/ledger_providers.dart';
import 'package:loan_manager/shared/widgets/bank_autocomplete_field.dart';
import 'package:shamsi_date/shamsi_date.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');
const List<String> _monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

int _monthIndex(int year, int month) => year * 12 + (month - 1);
int _yearOf(int index) => index ~/ 12;
int _monthOf(int index) => index % 12 + 1;
String _monthTitle(int index) => '${_monthNames[_monthOf(index) - 1]} ${toPersianDigits(_yearOf(index))}';

int? _indexOfKey(String yyyymm) {
  final parts = yyyymm.split('-');
  if (parts.length != 2) return null;
  final y = int.tryParse(parts[0]); final m = int.tryParse(parts[1]);
  if (y == null || m == null || m < 1 || m > 12) return null;
  return _monthIndex(y, m);
}

class MonthlyViewScreen extends ConsumerStatefulWidget {
  const MonthlyViewScreen({super.key});
  @override
  ConsumerState<MonthlyViewScreen> createState() => _MonthlyViewScreenState();
}

class _MonthlyViewScreenState extends ConsumerState<MonthlyViewScreen> {
  static const int _columns = 3; static const double _cellHeight = 64; static const double _spacing = 10; static const double _padding = 12;
  final ScrollController _controller = ScrollController(); bool _didInitialJump = false;
  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  void _jumpToCurrentMonth(int currentCellIndex) {
    if (_didInitialJump) return; _didInitialJump = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_controller.hasClients) return;
      final position = _controller.position; final row = currentCellIndex ~/ _columns;
      final rowTop = _padding + row * (_cellHeight + _spacing);
      final target = rowTop + _cellHeight / 2 - position.viewportDimension / 2;
      _controller.jumpTo(target.clamp(0.0, position.maxScrollExtent).toDouble());
    });
  }

  @override
  Widget build(BuildContext context) {
    final installmentsAsync = ref.watch(allInstallmentsProvider);
    return installmentsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('خطا: $e')),
      data: (installments) {
        if (installments.isEmpty) return const Center(child: Text('هنوز هیچ قسطی ثبت نشده'));
        final withInstallments = <int>{};
        for (final i in installments) { final index = _indexOfKey(i.jalaliMonth); if (index != null) withInstallments.add(index); }
        final now = Jalali.now(); final currentIndex = _monthIndex(now.year, now.month);
        if (withInstallments.isEmpty) return const Center(child: Text('هنوز هیچ قسطی ثبت نشده'));
        var first = withInstallments.reduce((a, b) => a < b ? a : b); var last = withInstallments.reduce((a, b) => a > b ? a : b);
        if (currentIndex < first) first = currentIndex; if (currentIndex > last) last = currentIndex;
        final count = last - first + 1;
        _jumpToCurrentMonth(currentIndex - first);
        final theme = Theme.of(context);
        return GridView.builder(
          controller: _controller, padding: const EdgeInsets.all(_padding),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: _columns, mainAxisSpacing: _spacing, crossAxisSpacing: _spacing, mainAxisExtent: _cellHeight),
          itemCount: count,
          itemBuilder: (context, position) {
            final index = first + position; final isCurrent = index == currentIndex; final hasItems = withInstallments.contains(index);
            final background = isCurrent ? theme.colorScheme.primaryContainer : hasItems ? theme.colorScheme.surfaceContainerHighest : theme.colorScheme.surfaceContainerLow;
            final foreground = isCurrent ? theme.colorScheme.onPrimaryContainer : hasItems ? theme.colorScheme.onSurface : theme.colorScheme.onSurfaceVariant.withValues(alpha: 0.6);
            return Material(color: background, borderRadius: BorderRadius.circular(16), child: InkWell(borderRadius: BorderRadius.circular(16), onTap: () => _openMonth(context, index), child: Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: Text(_monthTitle(index), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodyMedium?.copyWith(color: foreground, fontWeight: isCurrent ? FontWeight.bold : FontWeight.w500))))));
          },
        );
      },
    );
  }

  void _openMonth(BuildContext context, int monthIndex) {
    showModalBottomSheet<void>(context: context, isScrollControlled: true, showDragHandle: true, builder: (_) => DraggableScrollableSheet(expand: false, initialChildSize: 0.65, minChildSize: 0.35, maxChildSize: 0.95, builder: (context, scrollController) => _MonthSheet(monthIndex: monthIndex, scrollController: scrollController)));
  }
}

class _MonthSheet extends ConsumerWidget {
  const _MonthSheet({required this.monthIndex, required this.scrollController});
  final int monthIndex; final ScrollController scrollController;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final installments = ref.watch(allInstallmentsProvider).value ?? const <Installment>[];
    final loans = ref.watch(activeLoansProvider).value ?? const <Loan>[];
    final loansById = <String, Loan>{for (final l in loans) l.id: l};
    final items = installments.where((i) => _indexOfKey(i.jalaliMonth) == monthIndex).toList()..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final total = items.fold<int>(0, (s, i) => s + i.amount); final paid = items.fold<int>(0, (s, i) => s + i.paidAmount);
    return ListView(controller: scrollController, padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
      Text(_monthTitle(monthIndex), style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      if (items.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 32), child: Center(child: Text('قسطی در این ماه ثبت نشده')))
      else ...[
        Text('${items.length} قسط • جمع: ${_money.format(total)} تومان • پرداخت‌شده: ${_money.format(paid)} تومان', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        const SizedBox(height: 8),
        for (final i in items) _InstallmentTile(installment: i, loan: loansById[i.loanId]),
      ],
    ]);
  }
}

class _InstallmentTile extends StatelessWidget {
  const _InstallmentTile({required this.installment, required this.loan});
  final Installment installment; final Loan? loan;
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context); final loan = this.loan;
    return ListTile(
      contentPadding: EdgeInsets.zero, isThreeLine: loan != null,
      leading: CircleAvatar(child: Text(toPersianDigits(installment.sequenceNumber))),
      title: Text('سررسید: ${JalaliUtils.formatJalali(installment.dueDate)}'),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text('مبلغ: ${_money.format(installment.amount)} تومان'),
        if (loan != null) ...[const SizedBox(height: 4), Row(children: [BankLogo(bankName: loan.bankName ?? '', size: 16), const SizedBox(width: 6), Expanded(child: Text(_loanLabel(loan), maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.bodySmall))])],
      ]),
      trailing: installment.isFullyPaid ? const Icon(Icons.check_circle, color: Colors.green) : const Icon(Icons.pending, color: Colors.orange),
    );
  }
  String _loanLabel(Loan loan) { final bank = loan.bankName; return bank == null || bank.isEmpty ? loan.name : '${loan.name} • $bank'; }
}

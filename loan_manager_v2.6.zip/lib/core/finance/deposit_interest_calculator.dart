/// Interest = (Amount × AnnualRate% × Days) / 36500, in exact integer math.
/// The rate is given in basis points (23.5% = 2350), so Interest = Amount × bp × Days / 3 650 000
/// (rounded half up to a whole Toman). BigInt avoids any 64-bit overflow for huge deposits.
abstract final class DepositInterestCalculator {
  static int interest({required int amount, required int annualRateBp, required int days}) {
    if (amount < 0 || annualRateBp < 0 || days < 0) throw ArgumentError('Inputs must be >= 0');
    final num = BigInt.from(amount) * BigInt.from(annualRateBp) * BigInt.from(days);
    final den = BigInt.from(3650000);
    return ((num * BigInt.two + den) ~/ (den * BigInt.two)).toInt();
  }

  /// Inverse: annual rate (basis points, 2350 = 23.50%) that produced [interest] on [amount] in [days]:
  /// rate% = interest × 36500 / (amount × days), rounded half up.
  static int annualRateBp({required int amount, required int interest, required int days}) {
    if (amount <= 0 || days <= 0 || interest < 0) throw ArgumentError('Invalid inputs');
    final num = BigInt.from(interest) * BigInt.from(3650000);
    final den = BigInt.from(amount) * BigInt.from(days);
    return ((num * BigInt.two + den) ~/ (den * BigInt.two)).toInt();
  }
}

import 'package:flutter/material.dart';
import 'package:loan_manager/core/data/iranian_banks.dart';
import 'package:loan_manager/core/data/online_lenders.dart';
import 'package:loan_manager/shared/widgets/bank_autocomplete_field.dart';

/// Searchable "dropdown" for the lender: online lenders, banks and a final
/// «سایر موسسات (ورود دستی)» option. Every row shows the SVG logo and the name.
/// The parent owns the value; give the field a `ValueKey(value)` so it rebuilds when it changes.
class LenderPickerField extends FormField<String> {
  LenderPickerField({super.key, required String? value, required bool online, required ValueChanged<String> onChanged, super.validator})
      : super(
          initialValue: value,
          builder: (state) {
            final context = state.context;
            final selected = state.value;
            return InkWell(
              borderRadius: BorderRadius.circular(4),
              onTap: () async {
                final picked = await showLenderPickerSheet(context, selected, online: online);
                if (picked != null) {
                  state.didChange(picked);
                  onChanged(picked);
                }
              },
              child: InputDecorator(
                decoration: InputDecoration(
                  labelText: online ? 'وام‌دهنده آنلاین' : 'بانک',
                  border: const OutlineInputBorder(),
                  errorText: state.errorText,
                  suffixIcon: const Icon(Icons.arrow_drop_down_rounded),
                ),
                child: selected == null || selected.isEmpty
                    ? Text('انتخاب کنید', style: TextStyle(color: Theme.of(context).hintColor))
                    : Row(children: [
                        selected == OnlineLenders.manualOption
                            ? const Icon(Icons.edit_note_rounded, size: 28)
                            : BankLogo(bankName: selected, size: 28),
                        const SizedBox(width: 12),
                        Expanded(child: Text(selected, maxLines: 1, overflow: TextOverflow.ellipsis)),
                      ]),
              ),
            );
          },
        );
}

Future<String?> showLenderPickerSheet(BuildContext context, String? current, {required bool online}) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => _LenderSheet(current: current, online: online),
  );
}

class _LenderSheet extends StatefulWidget {
  const _LenderSheet({this.current, required this.online});
  final String? current;
  final bool online;
  @override
  State<_LenderSheet> createState() => _LenderSheetState();
}

class _LenderSheetState extends State<_LenderSheet> {
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  static String _norm(String s) => s.replaceAll('ي', 'ی').replaceAll('ك', 'ک').replaceAll('\u200c', '').replaceAll(' ', '');

  @override
  Widget build(BuildContext context) {
    final q = _norm(_search.text.trim());
    bool match(String name) => q.isEmpty || _norm(name).contains(q);
    // Each loan-type tab has its own list: banks, or online lenders. Every list ends with «سایر موسسات».
    final lenders = widget.online ? [for (final l in OnlineLenders.all) if (match(l.name)) l.name] : <String>[];
    final banks = widget.online ? <String>[] : [for (final b in IranianBanks.all) if (match(b)) b];
    final showManual = q.isEmpty || match(OnlineLenders.manualOption) || (lenders.isEmpty && banks.isEmpty);
    final theme = Theme.of(context);

    Widget header(String text) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text(text, style: theme.textTheme.labelLarge?.copyWith(color: theme.colorScheme.primary)),
        );
    Widget tile(String name, {Widget? leading}) => ListTile(
          leading: leading ?? BankLogo(bankName: name, size: 32),
          title: Text(name),
          trailing: widget.current == name ? Icon(Icons.check_rounded, color: theme.colorScheme.primary) : null,
          onTap: () => Navigator.pop(context, name),
        );

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.8,
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
              child: TextField(
                controller: _search,
                autofocus: false,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: widget.online ? 'جستجوی وام‌دهنده آنلاین' : 'جستجوی بانک', border: OutlineInputBorder()),
              ),
            ),
            Expanded(
              child: ListView(children: [
                if (lenders.isNotEmpty) ...[header('وام‌دهندگان آنلاین'), for (final n in lenders) tile(n)],
                if (banks.isNotEmpty) ...[header('بانک‌ها'), for (final n in banks) tile(n)],
                if (showManual) ...[
                  const Divider(),
                  tile(OnlineLenders.manualOption, leading: const SizedBox(width: 32, height: 32, child: Icon(Icons.edit_note_rounded))),
                ],
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

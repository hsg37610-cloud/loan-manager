/// Values stored in `loans.loan_type`.
abstract final class LoanType {
  static const String normal = 'normal';
  static const String qarz = 'qarz';

  /// وام آنلاین: behaves like a normal loan, but the lender is one of the online lenders.
  static const String online = 'online';

  /// وام با سپرده‌گذاری: the borrower must keep a deposit (part of it possibly blocked).
  static const String depositLoan = 'deposit_loan';
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/data/iranian_banks.dart';
import 'package:loan_manager/core/data/online_lenders.dart';
import 'package:loan_manager/core/finance/deposit_loan_calculator.dart';
import 'package:loan_manager/core/finance/interest_calculator.dart';
import 'package:loan_manager/core/router/app_router.dart';
import 'package:loan_manager/core/utils/input_utils.dart';
import 'package:loan_manager/features/ledger/presentation/ledger_providers.dart';
import 'package:loan_manager/shared/widgets/app_back_button.dart';
import 'package:loan_manager/shared/widgets/lender_picker_field.dart';
import 'package:loan_manager/shared/widgets/jalali_date_picker.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

class AddLoanScreen extends ConsumerStatefulWidget {
  final String? loanId;
  const AddLoanScreen({super.key, this.loanId});
  bool get isEditMode => loanId != null;
  @override
  ConsumerState<AddLoanScreen> createState() => _AddLoanScreenState();
}

class _AddLoanScreenState extends ConsumerState<AddLoanScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController(); final _principal = TextEditingController(); final _rate = TextEditingController();
  final _term = TextEditingController(); final _installment = TextEditingController(); final _fee = TextEditingController();
  final _serviceFee = TextEditingController(); final _manualInstallment = TextEditingController();
  final _penaltyRate = TextEditingController(); bool _penaltyEnabled = false;
  final _dueDay = TextEditingController(); final _facility = TextEditingController(); final _paymentLink = TextEditingController();

  // Loan with deposit (وام با سپرده)
  final _depositAmount = TextEditingController(); final _depositMonths = TextEditingController();
  final _blockedAmount = TextEditingController(); final _blockedMonths = TextEditingController(); final _nominalRate = TextEditingController();
  // Lender picker: a listed bank / online lender, or the manual option + free text
  String? _lenderChoice; final _manualLender = TextEditingController();

  String? get _selectedBank {
    if (_lenderChoice == OnlineLenders.manualOption) { final t = _manualLender.text.trim(); return t.isEmpty ? null : t; }
    return _lenderChoice;
  }

  final _blockedLoan = TextEditingController(); bool _blockedCheck = false; // normal / online loans: part of the loan is blocked
  String _loanType = 'normal'; bool _reverseCalc = false; DateTime? _firstDueDate;
  bool _isLoading = false; bool _hasPayments = false; bool _loaded = false;

  @override
  void initState() { super.initState(); if (widget.isEditMode) _loadExistingLoan(); }

  Future<void> _loadExistingLoan() async {
    setState(() => _isLoading = true);
    try {
      final repo = ref.read(ledgerRepositoryProvider);
      final loan = await repo.watchLoan(widget.loanId!).first;
      final installments = await repo.watchInstallmentsForLoan(widget.loanId!).first;
      final serviceFee = await repo.getServiceFee(widget.loanId!);
      final payments = await repo.watchPaymentsForLoan(widget.loanId!).first;
      if (loan != null && mounted) {
        setState(() {
          _name.text = loan.name; _applyLenderFromBankName(loan.bankName, loan.loanType); _principal.text = loan.principal.toString();
          _term.text = loan.termMonths.toString(); _rate.text = ((loan.annualRateBp ?? 0) / 100).toStringAsFixed(2);
          _fee.text = loan.feeAmount?.toString() ?? ''; _serviceFee.text = serviceFee?.toString() ?? '';
          _facility.text = loan.facilityNumber ?? ''; _paymentLink.text = loan.paymentLink ?? ''; _dueDay.text = loan.dueDay.toString();
          _penaltyEnabled = loan.penaltyRateBp != null; _penaltyRate.text = loan.penaltyRateBp == null ? '' : (loan.penaltyRateBp! / 100).toStringAsFixed(2);
          _firstDueDate = DateTime.tryParse(loan.firstDueDate); _loanType = loan.loanType;
          if (loan.loanType != 'deposit_loan' && (loan.blockedAmount ?? 0) > 0) { _blockedCheck = true; _blockedLoan.text = _money.format(loan.blockedAmount!); }
          if (loan.loanType == 'deposit_loan') {
            _depositAmount.text = _money.format(loan.depositAmount ?? 0); _depositMonths.text = (loan.depositMonths ?? 0).toString();
            final blocked = loan.blockedAmount ?? 0; _blockedAmount.text = blocked > 0 ? _money.format(blocked) : '';
            _blockedMonths.text = blocked > 0 ? (loan.blockedMonths ?? loan.termMonths).toString() : '';
            _nominalRate.text = ((loan.nominalRateBp ?? 0) / 100).toStringAsFixed(2);
          }
          _hasPayments = payments.isNotEmpty || installments.any((i) => i.paidAmount > 0);
          if (loan.loanType == 'qarz' && loan.termMonths >= 12 && loan.termMonths % 12 == 0 && loan.installmentAmount != loan.principal ~/ (11 * (loan.termMonths ~/ 12))) {
            _manualInstallment.text = loan.installmentAmount.toString();
          }
        });
      }
    } catch (_) {}
    if (mounted) setState(() { _isLoading = false; _loaded = true; });
  }

  bool _lenderValidFor(String name, String type) => type == 'online' ? OnlineLenders.isOnlineLender(name) : IranianBanks.all.contains(name);

  void _applyLenderFromBankName(String? bank, String type) {
    if (bank == null || bank.isEmpty) return;
    if (_lenderValidFor(bank, type)) { _lenderChoice = bank; }
    else { _lenderChoice = OnlineLenders.manualOption; _manualLender.text = bank; }
  }

  /// Every tab has its own lender list (banks / online lenders); a choice from the other list is dropped.
  void _onLoanTypeChanged(String type) {
    setState(() {
      _loanType = type;
      final c = _lenderChoice;
      if (c != null && c != OnlineLenders.manualOption && !_lenderValidFor(c, type)) _lenderChoice = null;
    });
  }

  @override
  void dispose() { for (final c in [_blockedLoan, _depositAmount, _depositMonths, _blockedAmount, _blockedMonths, _nominalRate, _manualLender, _name, _principal, _rate, _term, _installment, _fee, _serviceFee, _manualInstallment, _penaltyRate, _dueDay, _facility, _paymentLink]) { c.dispose(); } super.dispose(); }

  int? get _principalValue => parseInt(_principal.text);
  int? get _termValue => parseInt(_term.text);
  int? get _serviceFeeValue { final text = _serviceFee.text.trim(); return text.isEmpty ? null : parseInt(text); }
  int? get _manualValue { if (_loanType != 'qarz') return null; final text = _manualInstallment.text.trim(); return text.isEmpty ? null : parseInt(text); }

  bool get _isDeposit => _loanType == 'deposit_loan';
  bool get _isNormalLike => _loanType == 'normal' || _loanType == 'online'; // online = normal loan from an online lender
  int? get _blockedLoanValue => parseInt(_blockedLoan.text);
  String? _validateBlockedLoan(String? v) {
    if (!_blockedCheck) return null;
    final b = parseInt(v ?? ''); if (b == null || b <= 0) return 'مبلغ مسدودی را وارد کنید';
    final p = _principalValue; if (p != null && b > p) return 'مبلغ مسدودی نمی‌تواند از مبلغ وام بیشتر باشد';
    return null;
  }
  int? get _depositValue => parseInt(_depositAmount.text);
  int? get _depositMonthsValue => parseInt(_depositMonths.text);
  int get _blockedValue => parseInt(_blockedAmount.text) ?? 0;
  int? get _blockedMonthsValue => parseInt(_blockedMonths.text);
  int? get _nominalBp { final p = _parsePercent(_nominalRate.text); return (p == null || p < 0) ? null : (p * 100).round(); }

  /// Months used for the blocked part: nothing blocked -> null; blocked but months empty -> installment count.
  int? _effectiveBlockedMonths(int term) => DepositLoanCalculator.resolveBlockedMonths(blockedAmount: _blockedValue, blockedMonths: _blockedMonthsValue, termMonths: term);

  DepositLoanResult? _safeDepositPreview() {
    if (!_isDeposit) return null;
    final loan = _principalValue; final term = _termValue; final dep = _depositValue; final dm = _depositMonthsValue; final bp = _nominalBp;
    if (loan == null || loan <= 0 || term == null || term <= 0 || dep == null || dep < 0 || dm == null || dm < 1 || bp == null) return null;
    final blocked = _blockedValue; if (blocked < 0 || blocked > dep) return null;
    try { return DepositLoanCalculator.calculate(loanAmount: loan, depositAmount: dep, termMonths: term, nominalRateBp: bp, depositMonths: dm, blockedAmount: blocked, blockedMonths: _blockedMonthsValue); } catch (_) { return null; }
  }

  /// Blocked amount typed -> default the months to the installment count when still empty; cleared -> reset months.
  void _onBlockedAmountChanged() {
    if (_blockedValue <= 0) { _blockedMonths.clear(); }
    else if (_blockedMonths.text.trim().isEmpty && _termValue != null && _termValue! > 0) { _blockedMonths.text = _termValue.toString(); }
    setState(() {});
  }

  String? _validateDepositAmount(String? v) { final d = parseInt(v ?? ''); return (d == null || d <= 0) ? 'نامعتبر' : null; }
  String? _validateDepositMonths(String? v) { final m = parseInt(v ?? ''); return (m == null || m < 1) ? 'نامعتبر' : null; }
  String? _validateBlockedAmount(String? v) {
    if (v == null || v.trim().isEmpty) return null;
    final b = parseInt(v); if (b == null || b < 0) return 'نامعتبر';
    final d = _depositValue; if (d != null && b > d) return 'مبلغ مسدودی نمی‌تواند از مبلغ سپرده بیشتر باشد';
    return null;
  }
  String? _validateBlockedMonths(String? v) {
    if (_blockedValue <= 0 || v == null || v.trim().isEmpty) return null; // empty -> defaults to the installment count
    final m = parseInt(v); return (m == null || m < 1) ? 'نامعتبر' : null;
  }
  String? _validateNominalRate(String? v) { final p = _parsePercent(v ?? ''); return (p == null || p < 0) ? 'نامعتبر' : null; }

  double? _parsePercent(String text) {
    final cleaned = normalizeDigits(text).replaceAll('٫', '.').replaceAll(',', '.').trim();
    return double.tryParse(cleaned);
  }

  int? _reverseRateBp() {
    final p = _principalValue; final t = _termValue; final i = parseInt(_installment.text);
    if (p == null || t == null || i == null || p <= 0 || t <= 0 || i <= 0) return null;
    try { return InterestCalculator.findAnnualRateBpForInstallment(principal: p, termMonths: t, targetInstallment: i); } catch (_) { return null; }
  }

  int? get _rateBp {
    if (!_isNormalLike) return null;
    if (_reverseCalc) return _reverseRateBp();
    final percent = _parsePercent(_rate.text);
    if (percent == null || percent < 0) return null;
    return (percent * 100).round();
  }

  CalcBResult? _safePreview() {
    if (!_isNormalLike) return null;
    final p = _principalValue; final bp = _rateBp; final t = _termValue;
    if (p == null || p <= 0 || bp == null || t == null || t <= 0) return null;
    try { return InterestCalculator.calcB(principal: p, annualRateBp: bp, term: t); } catch (_) { return null; }
  }

  QarzAlHasanehResult? _safeQarzPreview() {
    if (_loanType != 'qarz') return null;
    final p = _principalValue; final f = parseInt(_fee.text); final t = _termValue;
    if (p == null || p <= 0 || f == null || f < 0 || t == null || t < 12 || t % 12 != 0) return null;
    try { return InterestCalculator.calcQarzAlHasaneh(principal: p, termMonths: t, feeAmount: f, manualInstallment: _manualValue); } catch (_) { return null; }
  }

  String? _effectiveRateText({required int totalInterest}) {
    final p = _principalValue; final t = _termValue;
    if (p == null || p <= 0 || t == null || t <= 0) return null;
    try {
      final bp = InterestCalculator.effectiveRateBpWithFee(principal: p, term: t, totalInterest: totalInterest, serviceFee: _serviceFeeValue ?? 0);
      return '${(bp / 100).toStringAsFixed(2)}٪';
    } catch (_) { return null; }
  }

  String? _validateTerm(String? v) {
    final t = parseInt(v ?? ''); if (t == null || t <= 0) return 'نامعتبر';
    if (_loanType == 'qarz' && (t < 12 || t % 12 != 0)) return 'برای قرض‌الحسنه تعداد اقساط باید مضرب ۱۲ باشد (هر سال: ۱۱ ماه اصل + ۱ ماه کارمزد)';
    return null;
  }

  String? _validateManualInstallment(String? v) {
    if (v == null || v.trim().isEmpty) return null;
    final m = parseInt(v); if (m == null || m <= 0) return 'نامعتبر';
    final p = _principalValue; final t = _termValue;
    if (p != null && t != null && t >= 12 && t % 12 == 0) {
      final principalMonths = 11 * (t ~/ 12);
      if (p - m * (principalMonths - 1) <= 0) return 'قسط دستی برای این اصل و مدت بیش از حد بزرگ است';
    }
    return null;
  }

  String? _validatePenaltyRate(String? v) {
    if (!_penaltyEnabled) return null;
    final text = (v ?? '').trim();
    if (text.isEmpty) return _loanType == 'qarz' ? 'الزامی' : null; // normal loans default to the annual rate
    final p = _parsePercent(text);
    return (p == null || p < 0) ? 'نامعتبر' : null;
  }

  /// Switch OFF -> null. Switch ON -> entered rate, or the loan's annual rate when left empty.
  int? _penaltyBpFor(int? annualRateBp) {
    if (!_penaltyEnabled) return null;
    final p = _parsePercent(_penaltyRate.text);
    if (p != null && p >= 0 && _penaltyRate.text.trim().isNotEmpty) return (p * 100).round();
    return annualRateBp;
  }

  String? _validateServiceFee(String? v) { if (v == null || v.trim().isEmpty) return null; final f = parseInt(v); if (f == null || f < 0) return 'نامعتبر'; return null; }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedBank == null) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_lenderChoice == OnlineLenders.manualOption ? 'لطفاً نام موسسه را وارد کنید' : 'لطفاً بانک یا اعتباردهنده را انتخاب کنید'))); return; }
    if (_firstDueDate == null) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لطفاً تاریخ اولین قسط را انتخاب کنید'))); return; }

    if (widget.isEditMode && _hasPayments) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('بازنویسی اقساط'),
          content: const Text('تغییر مبلغ وام باعث بازنویسی اقساط می‌شود. آیا مطمئن هستید؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تایید')),
          ],
        ),
      );
      if (confirmed != true || !mounted) return;
    }

    setState(() => _isLoading = true);
    final messenger = ScaffoldMessenger.of(context); final router = GoRouter.of(context);
    final principal = parseInt(_principal.text)!; final term = parseInt(_term.text)!; final dueDay = parseInt(_dueDay.text)!;
    final rateBp = _isNormalLike ? (_rateBp ?? 0) : null;
    final depositAmount = _isDeposit ? _depositValue : null; final depositMonths = _isDeposit ? _depositMonthsValue : null;
    final blockedAmount = _isDeposit ? _blockedValue : (_isNormalLike && _blockedCheck ? _blockedLoanValue : null); final blockedMonths = _isDeposit ? _effectiveBlockedMonths(term) : null;
    final nominalBp = _isDeposit ? _nominalBp : null;
    final fee = _loanType == 'qarz' ? (parseInt(_fee.text) ?? 0) : null;
    final manual = _manualValue; final serviceFee = _isDeposit ? null : _serviceFeeValue;
    final facility = _facility.text.isEmpty ? null : _facility.text; final paymentLink = _paymentLink.text.isEmpty ? null : _paymentLink.text;

    try {
      if (widget.isEditMode) {
        final ok = await ref.read(updateLoanProvider.notifier).submit(loanId: widget.loanId!, name: _name.text.trim(), bankName: _selectedBank!, principal: principal, annualRateBp: rateBp, feeAmount: fee, loanType: _loanType, termMonths: term, firstDueDate: _firstDueDate!, dueDayOfMonth: dueDay, facilityNumber: facility, paymentLink: paymentLink, manualInstallment: manual, serviceFee: serviceFee, penaltyRateBp: _penaltyBpFor(rateBp ?? nominalBp), depositAmount: depositAmount, depositMonths: depositMonths, blockedAmount: blockedAmount, blockedMonths: blockedMonths, nominalRateBp: nominalBp);
        if (ok) { messenger.showSnackBar(const SnackBar(content: Text('ویرایش شد'))); router.pop(); } else { messenger.showSnackBar(const SnackBar(content: Text('خطا در ویرایش وام'))); }
      } else {
        final loanId = await ref.read(createLoanProvider.notifier).submit(name: _name.text.trim(), bankName: _selectedBank!, principal: principal, annualRateBp: rateBp, feeAmount: fee, loanType: _loanType, termMonths: term, firstDueDate: _firstDueDate!, dueDayOfMonth: dueDay, facilityNumber: facility, paymentLink: paymentLink, manualInstallment: manual, serviceFee: serviceFee, penaltyRateBp: _penaltyBpFor(rateBp ?? nominalBp), depositAmount: depositAmount, depositMonths: depositMonths, blockedAmount: blockedAmount, blockedMonths: blockedMonths, nominalRateBp: nominalBp);
        if (loanId != null) { messenger.showSnackBar(const SnackBar(content: Text('ذخیره شد'))); router.pushReplacementNamed(AppRoutes.loanDetail, pathParameters: {'id': loanId}); } else { messenger.showSnackBar(const SnackBar(content: Text('خطا در ذخیره وام'))); }
      }
    } catch (e) { messenger.showSnackBar(SnackBar(content: Text('خطا: $e'))); } finally { if (mounted) setState(() => _isLoading = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isEditMode && !_loaded) return Scaffold(appBar: AppBar(automaticallyImplyLeading: false, title: const Text('ویرایش وام'), actions: const [AppBackButton()]), body: const Center(child: CircularProgressIndicator()));
    final preview = _safePreview(); final qarzPreview = _safeQarzPreview(); final reverseRateBp = _reverseCalc ? _reverseRateBp() : null; final depositPreview = _safeDepositPreview();

    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false, title: Text(widget.isEditMode ? 'ویرایش وام' : 'افزودن وام'), actions: const [AppBackButton()]),
      body: Form(key: _formKey, child: ListView(padding: const EdgeInsets.all(16), children: [
        const SizedBox(height: 16),
        // Four tabs: عادی / قرض‌الحسنه / وام با سپرده‌گذاری / آنلاین
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: SegmentedButton<String>(showSelectedIcon: false, segments: const [ButtonSegment(value: 'normal', label: Text('عادی')), ButtonSegment(value: 'qarz', label: Text('قرض‌الحسنه')), ButtonSegment(value: 'deposit_loan', label: Text('وام با سپرده‌گذاری')), ButtonSegment(value: 'online', label: Text('آنلاین'))], selected: {_loanType}, onSelectionChanged: (v) => _onLoanTypeChanged(v.first))),
        const SizedBox(height: 16),
        TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'عنوان وام', border: OutlineInputBorder()), validator: (v) => (v == null || v.isEmpty) ? 'الزامی' : null),
        const SizedBox(height: 16),
        LenderPickerField(key: ValueKey('$_loanType|$_lenderChoice'), online: _loanType == 'online', value: _lenderChoice, onChanged: (v) => setState(() { _lenderChoice = v; if (v != OnlineLenders.manualOption) _manualLender.clear(); }), validator: (_) => _lenderChoice == null ? 'الزامی' : null),
        if (_lenderChoice == OnlineLenders.manualOption) ...[
          const SizedBox(height: 16),
          TextFormField(controller: _manualLender, decoration: const InputDecoration(labelText: 'نام موسسه / اعتباردهنده', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => _lenderChoice == OnlineLenders.manualOption && (v == null || v.trim().isEmpty) ? 'الزامی' : null),
        ],
        const SizedBox(height: 16),
        if (_isDeposit) ..._depositFields() else ...[
        TextFormField(controller: _principal, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ اصل وام (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
        const SizedBox(height: 16),
        TextFormField(controller: _term, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: InputDecoration(labelText: 'تعداد اقساط (ماه)', helperText: _loanType == 'qarz' ? 'مضرب ۱۲؛ هر سال: ۱۱ ماه اصل + ۱ ماه کارمزد' : null, border: const OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateTerm),
        const SizedBox(height: 16),
        if (_isNormalLike) ...[
          SwitchListTile(title: const Text('محاسبه نرخ از روی مبلغ قسط'), value: _reverseCalc, onChanged: (v) => setState(() => _reverseCalc = v)),
          if (_reverseCalc) ...[
            TextFormField(controller: _installment, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ قسط (تومان)', border: OutlineInputBorder()), onChanged: (_) { final bp = _reverseRateBp(); setState(() { if (bp != null) _rate.text = (bp / 100).toStringAsFixed(2); }); }, validator: (_) => _reverseRateBp() == null ? 'نامعتبر' : null),
            if (reverseRateBp != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('نرخ سود محاسبه‌شده: ${(reverseRateBp / 100).toStringAsFixed(2)}٪', style: TextStyle(color: Theme.of(context).colorScheme.primary))),
            const SizedBox(height: 16),
          ] else ...[
            TextFormField(controller: _rate, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'نرخ سود سالانه (%)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => _parsePercent(v ?? '') == null ? 'نامعتبر' : null),
            const SizedBox(height: 16),
          ],
          CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, title: const Text('مبلغ مسدودی'), subtitle: const Text('بخشی از مبلغ وام مسدود می‌شود'), value: _blockedCheck, onChanged: (v) => setState(() { _blockedCheck = v ?? false; if (!_blockedCheck) _blockedLoan.clear(); })),
          if (_blockedCheck) ...[
            const SizedBox(height: 8),
            TextFormField(controller: _blockedLoan, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ مسدودی (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateBlockedLoan),
            if (_blockedLoanValue != null && _principalValue != null && _blockedLoanValue! > 0 && _blockedLoanValue! <= _principalValue!) Padding(padding: const EdgeInsets.only(top: 8), child: Text('مبلغ قابل استفاده: ${_money.format(_principalValue! - _blockedLoanValue!)} تومان', style: TextStyle(color: Theme.of(context).colorScheme.primary))),
          ],
          const SizedBox(height: 16),
        ] else ...[
          TextFormField(controller: _fee, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ کل کارمزد (تومان)', helperText: 'بین سال‌ها به‌صورت نزولی تقسیم می‌شود', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
          const SizedBox(height: 16),
          TextFormField(controller: _manualInstallment, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ قسط ماهانه (دستی)', helperText: 'اختیاری؛ اگر خالی بماند، اصل بر (۱۱ × تعداد سال) تقسیم می‌شود', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateManualInstallment),
          const SizedBox(height: 16),
        ],
        ],
        if (!_isDeposit) ...[
        TextFormField(controller: _serviceFee, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'کارمزد خدمات بانکی (تومان)', helperText: 'اختیاری؛ در نرخ مؤثر لحاظ می‌شود', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateServiceFee),
        const SizedBox(height: 16),
        ],
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('محاسبه جریمه دیرکرد'), value: _penaltyEnabled, onChanged: (v) => setState(() => _penaltyEnabled = v)),
        if (_penaltyEnabled) ...[
          TextFormField(controller: _penaltyRate, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: 'نرخ جریمه دیرکرد سالانه (%)', helperText: _loanType != 'qarz' ? 'اگر خالی بماند، نرخ سود سالانه وام استفاده می‌شود' : null, border: const OutlineInputBorder()), validator: _validatePenaltyRate),
          const SizedBox(height: 16),
        ],
        const SizedBox(height: 16),
        JalaliDatePicker(label: 'تاریخ اولین قسط', initialDate: _firstDueDate, onChanged: (v) => setState(() => _firstDueDate = v), validator: (_) => _firstDueDate == null ? 'الزامی' : null),
        const SizedBox(height: 16),
        TextFormField(controller: _dueDay, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: const InputDecoration(labelText: 'روز سررسید در ماه (1-31)', border: OutlineInputBorder()), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
        const SizedBox(height: 24),
        if (preview != null) _previewCard(['قسط ماهانه: ${_money.format(preview.installment)} تومان', 'کل بازپرداخت: ${_money.format(preview.totalReturn)} تومان', if (_serviceFeeValue != null && _serviceFeeValue! > 0) 'کارمزد خدمات بانکی: ${_money.format(_serviceFeeValue!)} تومان', if (_effectiveRateText(totalInterest: preview.totalInterest) != null) 'نرخ مؤثر (با کارمزد): ${_effectiveRateText(totalInterest: preview.totalInterest)}']),
        if (qarzPreview != null) _previewCard(['قسط ماهانه اصل: ${_money.format(qarzPreview.monthlyPrincipalInstallment)} تومان (${qarzPreview.principalMonths} ماه)', if (qarzPreview.lastPrincipalInstallment != qarzPreview.monthlyPrincipalInstallment) 'آخرین قسط اصل: ${_money.format(qarzPreview.lastPrincipalInstallment)} تومان', for (var k = 0; k < qarzPreview.yearlyFees.length; k++) 'کارمزد سال ${k + 1} (ماه ${12 * k + 1}): ${_money.format(qarzPreview.yearlyFees[k])} تومان', 'کل بازپرداخت: ${_money.format(qarzPreview.totalReturn)} تومان', if (_serviceFeeValue != null && _serviceFeeValue! > 0) 'کارمزد خدمات بانکی: ${_money.format(_serviceFeeValue!)} تومان', if (_effectiveRateText(totalInterest: qarzPreview.totalFee) != null) 'نرخ مؤثر (با کارمزد): ${_effectiveRateText(totalInterest: qarzPreview.totalFee)}']),
        if (_isDeposit) _depositPreviewCard(depositPreview),
        const SizedBox(height: 24),
        Card(child: ExpansionTile(title: const Text('بیشتر (شماره تسهیلات و لینک پرداخت)'), children: [Padding(padding: const EdgeInsets.all(16), child: Column(children: [TextFormField(controller: _facility, decoration: const InputDecoration(labelText: 'شماره تسهیلات', border: OutlineInputBorder())), const SizedBox(height: 12), TextFormField(controller: _paymentLink, decoration: const InputDecoration(labelText: 'لینک پرداخت', border: OutlineInputBorder()))]))])),
        const SizedBox(height: 32),
        FilledButton(onPressed: _isLoading ? null : _save, child: Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: _isLoading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(widget.isEditMode ? 'ذخیره تغییرات' : 'ثبت وام', style: const TextStyle(fontSize: 16)))),
        const SizedBox(height: 32),
      ])),
    );
  }

  List<Widget> _depositFields() {
    final blockedEnabled = _blockedValue > 0;
    final term = _termValue;
    return [
      TextFormField(controller: _depositAmount, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ سپرده (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateDepositAmount),
      const SizedBox(height: 16),
      TextFormField(controller: _depositMonths, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: const InputDecoration(labelText: 'مدت سپرده‌گذاری (ماه)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateDepositMonths),
      const SizedBox(height: 16),
      TextFormField(controller: _principal, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ وام دریافتی (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: (v) => parseInt(v ?? '') == null ? 'نامعتبر' : null),
      const SizedBox(height: 16),
      TextFormField(controller: _term, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: const InputDecoration(labelText: 'تعداد اقساط (ماه)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateTerm),
      const SizedBox(height: 16),
      TextFormField(controller: _nominalRate, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'بهره اسمی سالانه (%)', border: OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateNominalRate),
      const SizedBox(height: 16),
      TextFormField(controller: _blockedAmount, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter(thousands: true)], decoration: const InputDecoration(labelText: 'مبلغ مسدودی (تومان) - اختیاری', helperText: 'بخشی از سپرده که مسدود می‌شود؛ خالی یا صفر = بدون مسدودی', border: OutlineInputBorder()), onChanged: (_) => _onBlockedAmountChanged(), validator: _validateBlockedAmount),
      const SizedBox(height: 16),
      TextFormField(controller: _blockedMonths, enabled: blockedEnabled, keyboardType: TextInputType.number, inputFormatters: [const NumericInputFormatter()], decoration: InputDecoration(labelText: 'مدت مسدودی (ماه)', helperText: blockedEnabled ? 'اگر خالی بماند، برابر تعداد اقساط${term != null && term > 0 ? ' ($term ماه)' : ''} در نظر گرفته می‌شود' : 'ابتدا مبلغ مسدودی را وارد کنید', border: const OutlineInputBorder()), onChanged: (_) => setState(() {}), validator: _validateBlockedMonths),
      const SizedBox(height: 16),
    ];
  }

  Widget _depositPreviewCard(DepositLoanResult? r) {
    final theme = Theme.of(context);
    if (r == null) return Card(child: Padding(padding: const EdgeInsets.all(16), child: Text('برای مشاهده نرخ واقعی، همه فیلدهای وام و سپرده را کامل کنید', style: TextStyle(color: theme.colorScheme.onSurfaceVariant))));
    final ear = r.effectiveAnnualRate;
    return Card(color: theme.colorScheme.primaryContainer, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('نرخ بهره واقعی سالانه', style: theme.textTheme.titleSmall?.copyWith(color: theme.colorScheme.onPrimaryContainer)),
      Text(ear == null ? 'قابل محاسبه نیست' : '${(ear * 100).toStringAsFixed(2)}٪', style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimaryContainer)),
      const SizedBox(height: 8),
      Text('قسط ماهانه: ${_money.format(r.installment)} تومان'),
      Text('کل بازپرداخت: ${_money.format(r.totalReturn)} تومان'),
      if (r.blockedMonths != null) Text('مدت مسدودی: ${r.blockedMonths} ماه'),
    ])));
  }

  Widget _previewCard(List<String> lines) {
    return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final line in lines) Text(line)])));
  }
}

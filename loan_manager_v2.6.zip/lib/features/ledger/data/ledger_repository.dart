import 'package:drift/drift.dart';
import 'package:loan_manager/core/database/app_database.dart';
import 'package:loan_manager/core/finance/deposit_loan_calculator.dart';
import 'package:loan_manager/core/finance/interest_calculator.dart';
import 'package:loan_manager/core/finance/payment_allocator.dart';
import 'package:loan_manager/core/finance/schedule_generator.dart';
import 'package:loan_manager/core/utils/jalali_utils.dart';
import 'package:loan_manager/features/ledger/data/mappers.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:uuid/uuid.dart';

class LedgerException implements Exception {
  const LedgerException(this.message);
  final String message;
  @override String toString() => 'LedgerException: $message';
}

class LedgerRepository {
  LedgerRepository(this._db, {String Function()? idGenerator, DateTime Function()? clock}) : _newId = idGenerator ?? (() => const Uuid().v4()), _clock = clock ?? DateTime.now;
  final AppDatabase _db; final String Function() _newId; final DateTime Function() _clock; static const String _activeStatus = 'active';
  String _nowStamp() => _clock().toUtc().toIso8601String();

  Stream<List<Loan>> watchActiveLoans() { final query = _db.select(_db.loans)..where((t) => t.deletedAt.isNull() & t.status.equals(_activeStatus))..orderBy([(t) => OrderingTerm.asc(t.sortOrder), (t) => OrderingTerm.desc(t.createdAt)]); return query.watch().map((rows) => rows.toDomainList()); }
  Stream<List<Installment>> watchAllInstallments() { final query = _db.select(_db.installments).join([innerJoin(_db.loans, _db.loans.id.equalsExp(_db.installments.loanId))])..where(_db.loans.deletedAt.isNull())..orderBy([OrderingTerm.asc(_db.installments.dueDate)]); return query.watch().map((rows) => rows.map((r) => r.readTable(_db.installments)).toDomainList()); }
  Stream<List<Installment>> watchInstallmentsForLoan(String loanId) { final query = _db.select(_db.installments)..where((t) => t.loanId.equals(loanId))..orderBy([(t) => OrderingTerm.asc(t.sequenceNumber)]); return query.watch().map((rows) => rows.toDomainList()); }
  Stream<List<Payment>> watchPaymentsForLoan(String loanId) { final query = _db.select(_db.payments)..where((t) => t.loanId.equals(loanId) & t.deletedAt.isNull())..orderBy([(t) => OrderingTerm.desc(t.paymentDate), (t) => OrderingTerm.desc(t.createdAt)]); return query.watch().map((rows) => rows.toDomainList()); }
  Stream<Loan?> watchLoan(String loanId) { final query = _db.select(_db.loans)..where((t) => t.id.equals(loanId) & t.deletedAt.isNull()); return query.watchSingleOrNull().map((row) => row?.toDomain()); }

  List<ScheduleItem> _buildSchedule({required String loanType, required int principal, required int? annualRateBp, required int? feeAmount, required int termMonths, required DateTime firstDueDate, required int dueDayOfMonth, int? manualInstallment, DepositLoanResult? deposit}) {
    if (loanType == 'deposit_loan') return ScheduleGenerator.generate(principal: principal, totalInterest: deposit!.totalReturn - principal, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth);
    if (loanType == 'qarz') return ScheduleGenerator.generateQarzAlHasaneh(principal: principal, feeAmount: feeAmount ?? 0, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth, manualInstallment: manualInstallment);
    return ScheduleGenerator.generate(principal: principal, totalInterest: InterestCalculator.calcB(principal: principal, annualRateBp: annualRateBp ?? 0, term: termMonths).totalInterest, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth);
  }

  /// Cash-flow/IRR result for a «وام با سپرده» loan, null for other loan types.
  DepositLoanResult? _depositResult({required String loanType, required int principal, required int termMonths, int? depositAmount, int? depositMonths, int? blockedAmount, int? blockedMonths, int? nominalRateBp}) {
    if (loanType != 'deposit_loan') return null;
    if (depositAmount == null || depositMonths == null || nominalRateBp == null) throw const LedgerException('اطلاعات وام با سپرده ناقص است');
    return DepositLoanCalculator.calculate(loanAmount: principal, depositAmount: depositAmount, termMonths: termMonths, nominalRateBp: nominalRateBp, depositMonths: depositMonths, blockedAmount: blockedAmount ?? 0, blockedMonths: blockedMonths);
  }

  String _methodFor(String loanType) => loanType == 'qarz' ? 'qarz' : (loanType == 'deposit_loan' ? 'deposit_irr' : 'B');

  int _representativeAmount(String loanType, List<ScheduleItem> schedule) { if (loanType != 'qarz') return schedule.first.amount; return schedule.firstWhere((s) => (s.installmentNumber - 1) % 12 != 0, orElse: () => schedule.first).amount; }

  int _effectiveRateBp({DepositLoanResult? deposit, required String loanType, required int principal, required int termMonths, required int totalReturn, required int? annualRateBp, required int? serviceFee}) {
    if (deposit != null) return deposit.effectiveAnnualRateBp ?? 0;
    final fee = serviceFee ?? 0; if (loanType != 'qarz' && fee == 0) return annualRateBp ?? 0;
    return InterestCalculator.effectiveRateBpWithFee(principal: principal, term: termMonths, totalInterest: totalReturn - principal, serviceFee: fee);
  }

  Future<int?> getServiceFee(String loanId) async { final rows = await _db.customSelect('SELECT service_fee FROM loans WHERE id = ?', variables: [Variable<String>(loanId)], readsFrom: {_db.loans}).get(); if (rows.isEmpty) return null; return rows.first.readNullable<int>('service_fee'); }
  Future<void> _saveServiceFee(String loanId, int? serviceFee) async { await _db.customUpdate('UPDATE loans SET service_fee = ? WHERE id = ?', variables: [Variable<int>(serviceFee), Variable<String>(loanId)], updates: {_db.loans}); }

  /// Persists a manual ordering: the loan at index `i` gets `sortOrder = i`.
  Future<void> updateLoansOrder(List<String> orderedLoanIds) async {
    final stamp = _nowStamp();
    await _db.transaction(() async {
      for (var i = 0; i < orderedLoanIds.length; i++) {
        await (_db.update(_db.loans)..where((t) => t.id.equals(orderedLoanIds[i]))).write(LoansCompanion(sortOrder: Value(i), updatedAt: Value(stamp)));
      }
    });
  }

  Future<void> softDeleteLoan(String loanId) async { await (_db.update(_db.loans)..where((t) => t.id.equals(loanId))).write(LoansCompanion(deletedAt: Value(_nowStamp()), updatedAt: Value(_nowStamp()))); }

  Future<String> createLoan({required String name, required String bankName, required int principal, required int? annualRateBp, required int? feeAmount, required String loanType, required int termMonths, required DateTime firstDueDate, required int dueDayOfMonth, String? facilityNumber, String? paymentLink, int? manualInstallment, int? serviceFee, int? penaltyRateBp, int? depositAmount, int? depositMonths, int? blockedAmount, int? blockedMonths, int? nominalRateBp}) async {
    final deposit = _depositResult(loanType: loanType, principal: principal, termMonths: termMonths, depositAmount: depositAmount, depositMonths: depositMonths, blockedAmount: blockedAmount, blockedMonths: blockedMonths, nominalRateBp: nominalRateBp);
    final isDeposit = deposit != null;
    final schedule = _buildSchedule(loanType: loanType, principal: principal, annualRateBp: annualRateBp, feeAmount: feeAmount, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth, manualInstallment: manualInstallment, deposit: deposit);
    final totalReturn = schedule.fold<int>(0, (sum, s) => sum + s.amount); final loanId = _newId(); final now = _nowStamp();
    await _db.transaction(() async {
      await _db.into(_db.loans).insert(LoansCompanion(id: Value(loanId), userId: const Value('local'), name: Value(name), bankName: Value(bankName), principal: Value(principal), annualRateBp: Value(annualRateBp), termMonths: Value(termMonths), firstDueDate: Value(firstDueDate.toIso8601String().substring(0, 10)), dueDay: Value(dueDayOfMonth), installmentAmount: Value(_representativeAmount(loanType, schedule)), totalInterest: Value(totalReturn - principal), totalReturn: Value(totalReturn), effectiveRateBp: Value(_effectiveRateBp(deposit: deposit, loanType: loanType, principal: principal, termMonths: termMonths, totalReturn: totalReturn, annualRateBp: annualRateBp, serviceFee: serviceFee)), calculationMethod: Value(_methodFor(loanType)), loanType: Value(loanType), feeAmount: Value(feeAmount), penaltyRateBp: Value(penaltyRateBp), depositAmount: Value(isDeposit ? depositAmount : null), depositMonths: Value(isDeposit ? depositMonths : null), blockedAmount: Value(isDeposit ? (blockedAmount ?? 0) : ((blockedAmount ?? 0) > 0 ? blockedAmount : null)), blockedMonths: Value(isDeposit ? deposit?.blockedMonths : null), nominalRateBp: Value(isDeposit ? nominalRateBp : null), facilityNumber: Value(facilityNumber), paymentLink: Value(paymentLink), status: const Value('active'), createdAt: Value(now), updatedAt: Value(now)));
      await _saveServiceFee(loanId, serviceFee);
      await _db.batch((batch) { batch.insertAll(_db.installments, [for (final s in schedule) InstallmentsCompanion.insert(id: _newId(), loanId: loanId, sequenceNumber: s.installmentNumber, dueDate: s.dueDate, jalaliMonth: JalaliUtils.formatJalali(s.dueDate).substring(0, 7).replaceAll('/', '-'), amount: s.amount, createdAt: now, updatedAt: now)]); });
    });
    return loanId;
  }

  /// Rewrites the loan and its whole schedule. Existing payments are kept: their old
  /// allocations are dropped and every payment is re-allocated (FIFO, oldest payment
  /// first) against the freshly generated installments.
  Future<void> updateLoan({required String loanId, required String name, required String bankName, required int principal, required int? annualRateBp, required int? feeAmount, required String loanType, required int termMonths, required DateTime firstDueDate, required int dueDayOfMonth, String? facilityNumber, String? paymentLink, int? manualInstallment, int? serviceFee, int? penaltyRateBp, int? depositAmount, int? depositMonths, int? blockedAmount, int? blockedMonths, int? nominalRateBp}) async {
    final deposit = _depositResult(loanType: loanType, principal: principal, termMonths: termMonths, depositAmount: depositAmount, depositMonths: depositMonths, blockedAmount: blockedAmount, blockedMonths: blockedMonths, nominalRateBp: nominalRateBp);
    final isDeposit = deposit != null;
    final schedule = _buildSchedule(loanType: loanType, principal: principal, annualRateBp: annualRateBp, feeAmount: feeAmount, termMonths: termMonths, firstDueDate: firstDueDate, dueDayOfMonth: dueDayOfMonth, manualInstallment: manualInstallment, deposit: deposit);
    final totalReturn = schedule.fold<int>(0, (sum, s) => sum + s.amount);
    await _db.transaction(() async {
      await (_db.update(_db.loans)..where((t) => t.id.equals(loanId))).write(LoansCompanion(name: Value(name), bankName: Value(bankName), principal: Value(principal), termMonths: Value(termMonths), firstDueDate: Value(firstDueDate.toIso8601String().substring(0, 10)), dueDay: Value(dueDayOfMonth), installmentAmount: Value(_representativeAmount(loanType, schedule)), totalInterest: Value(totalReturn - principal), totalReturn: Value(totalReturn), effectiveRateBp: Value(_effectiveRateBp(deposit: deposit, loanType: loanType, principal: principal, termMonths: termMonths, totalReturn: totalReturn, annualRateBp: annualRateBp, serviceFee: serviceFee)), calculationMethod: Value(_methodFor(loanType)), annualRateBp: Value(annualRateBp), feeAmount: Value(feeAmount), penaltyRateBp: Value(penaltyRateBp), depositAmount: Value(isDeposit ? depositAmount : null), depositMonths: Value(isDeposit ? depositMonths : null), blockedAmount: Value(isDeposit ? (blockedAmount ?? 0) : ((blockedAmount ?? 0) > 0 ? blockedAmount : null)), blockedMonths: Value(isDeposit ? deposit?.blockedMonths : null), nominalRateBp: Value(isDeposit ? nominalRateBp : null), loanType: Value(loanType), facilityNumber: Value(facilityNumber), paymentLink: Value(paymentLink), updatedAt: Value(_nowStamp())));
      await _saveServiceFee(loanId, serviceFee);

      // 1. Drop everything that points at the old installments.
      final paymentIds = [for (final p in await (_db.select(_db.payments)..where((t) => t.loanId.equals(loanId))).get()) p.id];
      final oldInstallmentIds = [for (final i in await (_db.select(_db.installments)..where((t) => t.loanId.equals(loanId))).get()) i.id];
      if (paymentIds.isNotEmpty) await (_db.delete(_db.paymentAllocations)..where((t) => t.paymentId.isIn(paymentIds))).go();
      if (oldInstallmentIds.isNotEmpty) await (_db.delete(_db.installmentEvents)..where((t) => t.installmentId.isIn(oldInstallmentIds))).go();
      await (_db.delete(_db.installments)..where((t) => t.loanId.equals(loanId))).go();

      // 2. Insert the new schedule.
      final stamp = _nowStamp();
      await _db.batch((batch) { batch.insertAll(_db.installments, [for (final s in schedule) InstallmentsCompanion.insert(id: _newId(), loanId: loanId, sequenceNumber: s.installmentNumber, dueDate: s.dueDate, jalaliMonth: JalaliUtils.formatJalali(s.dueDate).substring(0, 7).replaceAll('/', '-'), amount: s.amount, createdAt: stamp, updatedAt: stamp)]); });

      // 3. Full FIFO recalculation of the loan's payments against the new installments.
      if (paymentIds.isNotEmpty) await _reallocateLoanPayments(loanId);
    });
  }

  /// Allocates [amount] FIFO (earliest due date first) to the unpaid installments of [loanId],
  /// stores the allocation rows and bumps `paidAmount`. Returns the unallocated remainder.
  Future<int> _allocatePayment({required String loanId, required String paymentId, required int amount}) async {
    final unpaidRows = await (_db.select(_db.installments)..where((t) => t.loanId.equals(loanId) & (t.amount - t.waivedAmount - t.paidAmount).isBiggerThanValue(0))..orderBy([(t) => OrderingTerm.asc(t.dueDate), (t) => OrderingTerm.asc(t.sequenceNumber)])).get();
    final allocatable = [for (final row in unpaidRows) AllocatableInstallment(id: row.id, dueDate: row.dueDate, amount: row.amount - row.waivedAmount, paidAmount: row.paidAmount)];
    final result = PaymentAllocator.allocate(paymentAmount: amount, installments: allocatable);
    if (result.allocations.isNotEmpty) { await _db.batch((batch) { batch.insertAll(_db.paymentAllocations, [for (final a in result.allocations) PaymentAllocationsCompanion.insert(id: _newId(), paymentId: paymentId, installmentId: Value(a.installmentId), amount: a.amountToApply, createdAt: _nowStamp())]); }); }
    for (final a in result.allocations) { await (_db.update(_db.installments)..where((t) => t.id.equals(a.installmentId))).write(InstallmentsCompanion.custom(paidAmount: _db.installments.paidAmount + Variable<int>(a.amountToApply))); }
    return result.unallocatedAmount;
  }

  /// Subtracts the payment's allocations from the installments' `paidAmount` and deletes them.
  Future<void> _reversePaymentAllocations(String paymentId) async {
    final allocations = await (_db.select(_db.paymentAllocations)..where((t) => t.paymentId.equals(paymentId))).get();
    for (final a in allocations) {
      final installmentId = a.installmentId;
      if (installmentId == null) continue;
      await (_db.update(_db.installments)..where((t) => t.id.equals(installmentId))).write(InstallmentsCompanion.custom(paidAmount: _db.installments.paidAmount - Variable<int>(a.amount)));
    }
    await (_db.delete(_db.paymentAllocations)..where((t) => t.paymentId.equals(paymentId))).go();
  }

  /// Re-allocates all payments of a loan, oldest first, onto installments whose `paidAmount` is 0.
  Future<void> _reallocateLoanPayments(String loanId) async {
    final payments = await (_db.select(_db.payments)..where((t) => t.loanId.equals(loanId) & t.deletedAt.isNull())..orderBy([(t) => OrderingTerm.asc(t.paymentDate), (t) => OrderingTerm.asc(t.createdAt)])).get();
    for (final payment in payments) {
      final unallocated = await _allocatePayment(loanId: loanId, paymentId: payment.id, amount: payment.amount);
      await (_db.update(_db.payments)..where((t) => t.id.equals(payment.id))).write(PaymentsCompanion(unallocatedAmount: Value(unallocated), updatedAt: Value(_nowStamp())));
    }
  }

  /// Deletes a payment and gives its allocated amounts back to the installments.
  Future<void> deletePayment(String paymentId) async {
    await _db.transaction(() async {
      await _reversePaymentAllocations(paymentId);
      await (_db.delete(_db.payments)..where((t) => t.id.equals(paymentId))).go();
    });
  }

  /// Changes a payment: its old allocations are reversed, the row is updated and the new
  /// amount is allocated FIFO again.
  Future<void> updatePayment({required String paymentId, required int amount, required String date, String? note}) async {
    if (amount <= 0) throw const LedgerException('Payment amount must be greater than zero.');
    await _db.transaction(() async {
      final payment = await (_db.select(_db.payments)..where((t) => t.id.equals(paymentId))).getSingleOrNull();
      if (payment == null) throw const LedgerException('Payment not found.');
      await _reversePaymentAllocations(paymentId);
      final unallocated = await _allocatePayment(loanId: payment.loanId, paymentId: paymentId, amount: amount);
      await (_db.update(_db.payments)..where((t) => t.id.equals(paymentId))).write(PaymentsCompanion(paymentDate: Value(date), amount: Value(amount), unallocatedAmount: Value(unallocated), note: Value(note), updatedAt: Value(_nowStamp())));
    });
  }

  Future<void> recordPayment({required String loanId, required int amount, required String date, String? note}) async {
    if (amount <= 0) throw const LedgerException('Payment amount must be greater than zero.');
    await _db.transaction(() async {
      final unpaidRows = await (_db.select(_db.installments)..where((t) => t.loanId.equals(loanId) & (t.amount - t.waivedAmount - t.paidAmount).isBiggerThanValue(0))..orderBy([(t) => OrderingTerm.asc(t.dueDate), (t) => OrderingTerm.asc(t.sequenceNumber)])).get();
      final allocatable = [for (final row in unpaidRows) AllocatableInstallment(id: row.id, dueDate: row.dueDate, amount: row.amount - row.waivedAmount, paidAmount: row.paidAmount)];
      final result = PaymentAllocator.allocate(paymentAmount: amount, installments: allocatable);
      final paymentId = _newId();
      await _db.into(_db.payments).insert(PaymentsCompanion.insert(id: paymentId, loanId: loanId, paymentDate: date, amount: amount, unallocatedAmount: Value(result.unallocatedAmount), note: Value(note), createdAt: _nowStamp(), updatedAt: _nowStamp()));
      if (result.allocations.isNotEmpty) { await _db.batch((batch) { batch.insertAll(_db.paymentAllocations, [for (final a in result.allocations) PaymentAllocationsCompanion.insert(id: _newId(), paymentId: paymentId, installmentId: Value(a.installmentId), amount: a.amountToApply, createdAt: _nowStamp())]); }); }
      for (final a in result.allocations) { await (_db.update(_db.installments)..where((t) => t.id.equals(a.installmentId))).write(InstallmentsCompanion.custom(paidAmount: _db.installments.paidAmount + Variable<int>(a.amountToApply))); }
    });
  }
}

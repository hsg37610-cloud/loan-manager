import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/finance/deposit_loan_calculator.dart';
import 'package:loan_manager/core/utils/input_utils.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

/// محاسبه وام با سپرده‌گذاری: nothing is saved, it only outputs the real (effective) rate.
class DepositLoanCalculatorScreen extends StatefulWidget {
  const DepositLoanCalculatorScreen({super.key});
  @override
  State<DepositLoanCalculatorScreen> createState() => _DepositLoanCalculatorScreenState();
}

class _DepositLoanCalculatorScreenState extends State<DepositLoanCalculatorScreen> {
  final _deposit = TextEditingController();
  final _depositMonths = TextEditingController();
  final _loan = TextEditingController();
  final _term = TextEditingController();
  final _rate = TextEditingController();
  final _blocked = TextEditingController();
  final _blockedMonths = TextEditingController();

  @override
  void dispose() {
    for (final c in [_deposit, _depositMonths, _loan, _term, _rate, _blocked, _blockedMonths]) {
      c.dispose();
    }
    super.dispose();
  }

  int get _blockedValue => parseInt(_blocked.text) ?? 0;

  int? get _nominalBp {
    final cleaned = normalizeDigits(_rate.text).replaceAll('٫', '.').replaceAll(',', '.').trim();
    final p = double.tryParse(cleaned);
    return (p == null || p < 0) ? null : (p * 100).round();
  }

  /// Blocked amount typed -> months default to the loan term while still empty; cleared -> months reset.
  void _onBlockedChanged() {
    final term = parseInt(_term.text);
    if (_blockedValue <= 0) {
      _blockedMonths.clear();
    } else if (_blockedMonths.text.trim().isEmpty && term != null && term > 0) {
      _blockedMonths.text = term.toString();
    }
    setState(() {});
  }

  DepositLoanResult? _result() {
    final loan = parseInt(_loan.text);
    final term = parseInt(_term.text);
    final dep = parseInt(_deposit.text);
    final dm = parseInt(_depositMonths.text);
    final bp = _nominalBp;
    if (loan == null || loan <= 0 || term == null || term <= 0 || dep == null || dep < 0 || dm == null || dm < 1 || bp == null) return null;
    if (_blockedValue > dep) return null;
    try {
      return DepositLoanCalculator.calculate(
        loanAmount: loan,
        depositAmount: dep,
        termMonths: term,
        nominalRateBp: bp,
        depositMonths: dm,
        blockedAmount: _blockedValue,
        blockedMonths: parseInt(_blockedMonths.text),
      );
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final r = _result();
    final blockedEnabled = _blockedValue > 0;
    final term = parseInt(_term.text);
    final money = [const NumericInputFormatter(thousands: true)];
    final plain = [const NumericInputFormatter()];
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('محاسبه وام با سپرده‌گذاری', style: theme.textTheme.titleLarge),
        const SizedBox(height: 16),
        TextField(controller: _deposit, keyboardType: TextInputType.number, inputFormatters: money, decoration: const InputDecoration(labelText: 'مبلغ سپرده (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {})),
        const SizedBox(height: 16),
        TextField(controller: _depositMonths, keyboardType: TextInputType.number, inputFormatters: plain, decoration: const InputDecoration(labelText: 'مدت سپرده‌گذاری (ماه)', border: OutlineInputBorder()), onChanged: (_) => setState(() {})),
        const SizedBox(height: 16),
        TextField(controller: _loan, keyboardType: TextInputType.number, inputFormatters: money, decoration: const InputDecoration(labelText: 'مبلغ وام دریافتی (تومان)', border: OutlineInputBorder()), onChanged: (_) => setState(() {})),
        const SizedBox(height: 16),
        TextField(controller: _term, keyboardType: TextInputType.number, inputFormatters: plain, decoration: const InputDecoration(labelText: 'تعداد اقساط (ماه)', border: OutlineInputBorder()), onChanged: (_) => setState(() {})),
        const SizedBox(height: 16),
        TextField(controller: _rate, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'بهره اسمی سالانه (%)', border: OutlineInputBorder()), onChanged: (_) => setState(() {})),
        const SizedBox(height: 16),
        TextField(
          controller: _blocked,
          keyboardType: TextInputType.number,
          inputFormatters: money,
          decoration: InputDecoration(
            labelText: 'مبلغ مسدودی (تومان)',
            helperText: 'اگر خالی باشد یعنی مسدودی نداریم',
            errorText: (parseInt(_deposit.text) != null && _blockedValue > parseInt(_deposit.text)!) ? 'مبلغ مسدودی نمی‌تواند از مبلغ سپرده بیشتر باشد' : null,
            border: const OutlineInputBorder(),
          ),
          onChanged: (_) => _onBlockedChanged(),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _blockedMonths,
          enabled: blockedEnabled,
          keyboardType: TextInputType.number,
          inputFormatters: plain,
          decoration: InputDecoration(
            labelText: 'مدت مسدودی (ماه)',
            helperText: blockedEnabled ? 'پیش‌فرض برابر مدت وام${term != null && term > 0 ? ' ($term ماه)' : ''}؛ دستی هم قابل تغییر است' : 'ابتدا مبلغ مسدودی را وارد کنید',
            border: const OutlineInputBorder(),
          ),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 24),
        if (r == null)
          Text('همه فیلدها را کامل وارد کنید', style: TextStyle(color: theme.colorScheme.outline))
        else
          Card(
            color: theme.colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('نرخ بهره واقعی سالانه', style: theme.textTheme.titleSmall?.copyWith(color: theme.colorScheme.onPrimaryContainer)),
                Text(
                  r.effectiveAnnualRate == null ? 'قابل محاسبه نیست' : '${(r.effectiveAnnualRate! * 100).toStringAsFixed(2)}٪',
                  style: theme.textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimaryContainer),
                ),
                const SizedBox(height: 8),
                if (r.monthlyRate != null) Text('نرخ واقعی ماهانه: ${(r.monthlyRate! * 100).toStringAsFixed(3)}٪', style: TextStyle(color: theme.colorScheme.onPrimaryContainer)),
                Text('قسط ماهانه: ${_money.format(r.installment)} تومان', style: TextStyle(color: theme.colorScheme.onPrimaryContainer)),
                Text('کل بازپرداخت: ${_money.format(r.totalReturn)} تومان', style: TextStyle(color: theme.colorScheme.onPrimaryContainer)),
                if (r.blockedMonths != null) Text('مدت مسدودی: ${r.blockedMonths} ماه', style: TextStyle(color: theme.colorScheme.onPrimaryContainer)),
              ]),
            ),
          ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:loan_manager/core/finance/deposit_interest_calculator.dart';
import 'package:loan_manager/core/utils/input_utils.dart';

final NumberFormat _money = NumberFormat.decimalPattern('en');

enum _Mode { interestAmount, interestRate }

/// محاسبه سود سپرده. Two modes:
///  - مبلغ سود:  Interest = (Amount × AnnualRate × Days) / 36500
///  - درصد سود:  AnnualRate = (Interest × 36500) / (Amount × Days)
class DepositInterestScreen extends StatefulWidget {
  const DepositInterestScreen({super.key});
  @override
  State<DepositInterestScreen> createState() => _DepositInterestScreenState();
}

class _DepositInterestScreenState extends State<DepositInterestScreen> {
  final _amount = TextEditingController();
  final _rate = TextEditingController();
  final _interestInput = TextEditingController();
  final _days = TextEditingController();
  _Mode _mode = _Mode.interestAmount;

  @override
  void dispose() {
    _amount.dispose();
    _rate.dispose();
    _interestInput.dispose();
    _days.dispose();
    super.dispose();
  }

  int? get _rateBp {
    final cleaned = normalizeDigits(_rate.text).replaceAll('٫', '.').replaceAll(',', '.').trim();
    final p = double.tryParse(cleaned);
    return (p == null || p < 0) ? null : (p * 100).round();
  }

  int? get _interest {
    final a = parseInt(_amount.text);
    final d = parseInt(_days.text);
    final bp = _rateBp;
    if (a == null || a <= 0 || d == null || d <= 0 || bp == null) return null;
    return DepositInterestCalculator.interest(amount: a, annualRateBp: bp, days: d);
  }

  int? get _resultRateBp {
    final a = parseInt(_amount.text);
    final d = parseInt(_days.text);
    final i = parseInt(_interestInput.text);
    if (a == null || a <= 0 || d == null || d <= 0 || i == null || i < 0) return null;
    return DepositInterestCalculator.annualRateBp(amount: a, interest: i, days: d);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final byAmount = _mode == _Mode.interestAmount;
    final amount = parseInt(_amount.text);
    final interest = byAmount ? _interest : parseInt(_interestInput.text);
    final rateBp = byAmount ? _rateBp : _resultRateBp;
    final hasResult = byAmount ? _interest != null : _resultRateBp != null;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('محاسبه سود سپرده', style: theme.textTheme.titleLarge),
        const SizedBox(height: 12),
        SegmentedButton<_Mode>(
          showSelectedIcon: false,
          segments: const [
            ButtonSegment(value: _Mode.interestAmount, label: Text('محاسبه مبلغ سود')),
            ButtonSegment(value: _Mode.interestRate, label: Text('محاسبه درصد سود')),
          ],
          selected: {_mode},
          onSelectionChanged: (v) => setState(() => _mode = v.first),
        ),
        const SizedBox(height: 8),
        Text(
          byAmount ? 'سود = (مبلغ × نرخ سالانه × تعداد روز) ÷ ۳۶۵۰۰' : 'نرخ سالانه = (مبلغ سود × ۳۶۵۰۰) ÷ (مبلغ × تعداد روز)',
          style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _amount,
          keyboardType: TextInputType.number,
          inputFormatters: [const NumericInputFormatter(thousands: true)],
          decoration: const InputDecoration(labelText: 'مبلغ سپرده (تومان)', border: OutlineInputBorder()),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 16),
        if (byAmount)
          TextField(
            controller: _rate,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'نرخ سود سالانه (%)', border: OutlineInputBorder()),
            onChanged: (_) => setState(() {}),
          )
        else
          TextField(
            controller: _interestInput,
            keyboardType: TextInputType.number,
            inputFormatters: [const NumericInputFormatter(thousands: true)],
            decoration: const InputDecoration(labelText: 'مبلغ سود دریافتی (تومان)', border: OutlineInputBorder()),
            onChanged: (_) => setState(() {}),
          ),
        const SizedBox(height: 16),
        TextField(
          controller: _days,
          keyboardType: TextInputType.number,
          inputFormatters: [const NumericInputFormatter()],
          decoration: const InputDecoration(labelText: 'مدت (روز)', border: OutlineInputBorder()),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 24),
        if (hasResult)
          Card(
            color: theme.colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(byAmount ? 'مبلغ سود سپرده' : 'درصد سود سالانه', style: theme.textTheme.titleSmall?.copyWith(color: theme.colorScheme.onPrimaryContainer)),
                Text(
                  byAmount ? '${_money.format(interest)} تومان' : '${(rateBp! / 100).toStringAsFixed(2)}٪',
                  style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, color: theme.colorScheme.onPrimaryContainer),
                ),
                if (byAmount && amount != null) ...[
                  const SizedBox(height: 8),
                  Text('مبلغ سپرده + سود: ${_money.format(amount + interest!)} تومان', style: TextStyle(color: theme.colorScheme.onPrimaryContainer)),
                ],
              ]),
            ),
          )
        else
          Text(byAmount ? 'مبلغ، نرخ و تعداد روز را وارد کنید' : 'مبلغ سپرده، مبلغ سود و تعداد روز را وارد کنید', style: TextStyle(color: theme.colorScheme.outline)),
      ],
    );
  }
}

import 'package:loan_manager/core/database/app_database_provider.dart';
import 'package:loan_manager/features/ledger/data/ledger_repository.dart';
import 'package:loan_manager/features/ledger/data/reminder_sync.dart';
import 'package:loan_manager/features/ledger/domain/models.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'ledger_providers.g.dart';

@Riverpod(keepAlive: true)
LedgerRepository ledgerRepository(Ref ref) => LedgerRepository(ref.watch(appDatabaseProvider));

@riverpod
Stream<List<Loan>> activeLoans(Ref ref) => ref.watch(ledgerRepositoryProvider).watchActiveLoans();

@riverpod
Stream<Loan?> loanById(Ref ref, String loanId) => ref.watch(ledgerRepositoryProvider).watchLoan(loanId);

@riverpod
Stream<List<Installment>> allInstallments(Ref ref) =>
    ref.watch(ledgerRepositoryProvider).watchAllInstallments();

@riverpod
Stream<List<Installment>> loanInstallments(Ref ref, String loanId) =>
    ref.watch(ledgerRepositoryProvider).watchInstallmentsForLoan(loanId);

// NOTE: in the notifiers below, `ref.read(...)` is done BEFORE the first `await` and the
// objects are captured in locals. The notifiers are keepAlive, and after every `await`
// we still check `ref.mounted` before touching `state`, so a disposed notifier can never
// throw "Cannot use the Ref ... after it has been disposed".

@Riverpod(keepAlive: true)
class RecordPayment extends _$RecordPayment {
  @override
  FutureOr<void> build() {}

  Future<bool> submit({required String loanId, required int amount, required String date, String? note}) async {
    final repo = ref.read(ledgerRepositoryProvider);
    final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() async {
      await repo.recordPayment(loanId: loanId, amount: amount, date: date, note: note);
      // Fully paid installments lose their reminder; partially paid ones get the new remaining amount.
      await reminders.syncLoan(loanId);
    });
    if (!ref.mounted) return !result.hasError;
    state = result;
    return !result.hasError;
  }
}

@Riverpod(keepAlive: true)
class CreateLoan extends _$CreateLoan {
  @override
  FutureOr<String?> build() => null;

  Future<String?> submit({
    required String name,
    required String bankName,
    required int principal,
    required int? annualRateBp,
    required int? feeAmount,
    required String loanType,
    required int termMonths,
    required DateTime firstDueDate,
    required int dueDayOfMonth,
    String? facilityNumber,
    String? paymentLink,
    int? manualInstallment,
  }) async {
    final repo = ref.read(ledgerRepositoryProvider);
    final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard<String?>(() async {
      final loanId = await repo.createLoan(
        name: name,
        bankName: bankName,
        principal: principal,
        annualRateBp: annualRateBp,
        feeAmount: feeAmount,
        loanType: loanType,
        termMonths: termMonths,
        firstDueDate: firstDueDate,
        dueDayOfMonth: dueDayOfMonth,
        facilityNumber: facilityNumber,
        paymentLink: paymentLink,
        manualInstallment: manualInstallment,
      );
      await reminders.syncLoan(loanId);
      return loanId;
    });
    // The loan is already saved at this point, so the id is returned even if the notifier
    // was disposed meanwhile; only the `state` write is skipped.
    if (!ref.mounted) return result.value;
    state = result;
    return result.value;
  }
}

@Riverpod(keepAlive: true)
class UpdateLoan extends _$UpdateLoan {
  @override
  FutureOr<void> build() {}

  Future<bool> submit({
    required String loanId,
    required String name,
    required String bankName,
    required int principal,
    required int? annualRateBp,
    required int? feeAmount,
    required String loanType,
    required int termMonths,
    required DateTime firstDueDate,
    required int dueDayOfMonth,
    String? facilityNumber,
    String? paymentLink,
    int? manualInstallment,
  }) async {
    final repo = ref.read(ledgerRepositoryProvider);
    final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() async {
      // updateLoan() replaces the installment rows (new ids) when there are no payments,
      // so remember the old ids to cancel their reminders.
      final oldIds = (await repo.watchInstallmentsForLoan(loanId).first).map((i) => i.id).toList();
      await repo.updateLoan(
        loanId: loanId,
        name: name,
        bankName: bankName,
        principal: principal,
        annualRateBp: annualRateBp,
        feeAmount: feeAmount,
        loanType: loanType,
        termMonths: termMonths,
        firstDueDate: firstDueDate,
        dueDayOfMonth: dueDayOfMonth,
        facilityNumber: facilityNumber,
        paymentLink: paymentLink,
        manualInstallment: manualInstallment,
      );
      await reminders.replaceForLoan(loanId, oldIds);
    });
    if (!ref.mounted) return !result.hasError;
    state = result;
    return !result.hasError;
  }
}

@Riverpod(keepAlive: true)
class DeleteLoan extends _$DeleteLoan {
  @override
  FutureOr<void> build() {}

  /// Soft-deletes the loan (sets deleted_at) and cancels its reminders.
  Future<bool> submit(String loanId) async {
    final repo = ref.read(ledgerRepositoryProvider);
    final reminders = ref.read(reminderSyncProvider);
    state = const AsyncLoading();
    final result = await AsyncValue.guard(() async {
      await repo.softDeleteLoan(loanId);
      // syncLoan() sees the loan as deleted and cancels every installment reminder.
      await reminders.syncLoan(loanId);
    });
    if (!ref.mounted) return !result.hasError;
    state = result;
    return !result.hasError;
  }
}

import 'package:shamsi_date/shamsi_date.dart';
import 'finance_math.dart';

class ScheduleItem {
  final int installmentNumber;
  final String dueDate; // Gregorian YYYY-MM-DD
  final int amount;
  const ScheduleItem(this.installmentNumber, this.dueDate, this.amount);
}

class ScheduleGenerator {
  ScheduleGenerator._();

  static String _iso(Gregorian g) =>
      '${g.year.toString().padLeft(4, '0')}-'
      '${g.month.toString().padLeft(2, '0')}-'
      '${g.day.toString().padLeft(2, '0')}';

  /// Qarz-al-Hasaneh schedule: (termMonths - 1) principal installments, then one final
  /// installment that is exactly [feeAmount] (the Karmozd).
  ///
  /// By default every principal installment is `principal ~/ principalMonths` and the
  /// remainder goes to the LAST principal installment (month principalMonths), so the
  /// principal installments always add up to [principal].
  ///
  /// With [manualInstallment] the user's amount replaces the calculated one for every
  /// principal installment; the last principal installment still absorbs the difference
  /// (it can be a bit smaller or larger), so the total repaid stays principal + fee.
  static List<ScheduleItem> generateQarzAlHasaneh({
    required int principal,
    required int feeAmount,
    required int termMonths,
    required DateTime firstDueDate,
    required int dueDayOfMonth,
    int? manualInstallment,
  }) {
    if (principal <= 0) throw ArgumentError('Principal must be > 0');
    if (feeAmount < 0) throw ArgumentError('Fee must be >= 0');
    if (termMonths < 2) throw ArgumentError('Term must be >= 2 for qarz-al-hasaneh');
    if (dueDayOfMonth < 1 || dueDayOfMonth > 31) {
      throw ArgumentError('dueDayOfMonth must be 1..31');
    }
    if (manualInstallment != null && manualInstallment <= 0) {
      throw ArgumentError('Manual installment must be > 0');
    }

    final principalMonths = termMonths - 1;
    final baseInstallment = manualInstallment ?? principal ~/ principalMonths;
    final remainder = principal - (baseInstallment * principalMonths);
    final lastPrincipalInstallment = baseInstallment + remainder;
    if (lastPrincipalInstallment <= 0) {
      throw ArgumentError('Manual installment is too large for this principal and term');
    }

    final items = <ScheduleItem>[];
    final start = Jalali.fromDateTime(firstDueDate);

    String dueFor(int monthOffset) {
      final idx = start.month - 1 + monthOffset;
      final year = start.year + idx ~/ 12;
      final month = idx % 12 + 1;
      final len = Jalali(year, month, 1).monthLength;
      final day = dueDayOfMonth > len ? len : dueDayOfMonth;
      return _iso(Jalali(year, month, day).toGregorian());
    }

    for (var i = 1; i <= principalMonths; i++) {
      final amount = i == principalMonths ? lastPrincipalInstallment : baseInstallment;
      items.add(ScheduleItem(i, dueFor(i - 1), amount));
    }
    items.add(ScheduleItem(termMonths, dueFor(principalMonths), feeAmount));
    return items;
  }

  static List<ScheduleItem> generate({
    required int principal,
    required int totalInterest,
    required int termMonths,
    required DateTime firstDueDate,
    required int dueDayOfMonth,
  }) {
    if (principal <= 0) throw ArgumentError('Principal must be > 0');
    if (totalInterest < 0) throw ArgumentError('Interest must be >= 0');
    if (termMonths <= 0) throw ArgumentError('Term must be > 0');
    if (dueDayOfMonth < 1 || dueDayOfMonth > 31) {
      throw ArgumentError('dueDayOfMonth must be 1..31');
    }

    final totalReturn = principal + totalInterest;
    final regular = roundDiv(totalReturn, termMonths);
    final start = Jalali.fromDateTime(firstDueDate);

    final items = <ScheduleItem>[];
    for (var i = 0; i < termMonths; i++) {
      final idx = start.month - 1 + i;
      final year = start.year + idx ~/ 12;
      final month = idx % 12 + 1;
      final len = Jalali(year, month, 1).monthLength;
      final day = dueDayOfMonth > len ? len : dueDayOfMonth;
      final due = Jalali(year, month, day).toGregorian();
      final amount =
          i == termMonths - 1 ? totalReturn - regular * (termMonths - 1) : regular;
      items.add(ScheduleItem(i + 1, _iso(due), amount));
    }
    return items;
  }
}
